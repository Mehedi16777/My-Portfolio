export type Language = 'en' | 'bn';

export type LocalizedText = {
  en: string;
  bn: string;
};

export type SkillCategoryId = 'programming' | 'frontend' | 'backend' | 'ai_ml';

export type SkillUsageStatus = 'used' | 'learning';

export interface SkillItem {
  id: string;
  name: string;
  category: SkillCategoryId;
  status: SkillUsageStatus;
  note: LocalizedText;
}

export type ProjectSlug =
  | 'bus-ticket-reservation'
  | 'sagar-pahar-ai-travel-agent';

export type ProjectDevelopmentStage = 'academic_personal' | 'concept_prototype';

export interface ProjectWorkflowStep {
  step: string;
  title: LocalizedText;
  detail: LocalizedText;
}

export interface ProjectData {
  slug: ProjectSlug;
  title: string;
  subtitle: LocalizedText;
  stage: ProjectDevelopmentStage;
  stageLabel: LocalizedText;
  shortDescription: LocalizedText;
  overview: LocalizedText;
  problemStatement: LocalizedText;
  targetUsers?: LocalizedText;
  proposedSolution?: LocalizedText;
  contribution: LocalizedText;
  challengesAndLearning: LocalizedText;
  implementedFeatures: LocalizedText[];
  plannedFeatures: LocalizedText[];
  confirmedTechnologies: string[];
  /** Editable placeholder note when stack details are still being documented */
  stackNote: LocalizedText;
  workflowSteps?: ProjectWorkflowStep[];
  destinations?: string[];
  /** Leave null until real verified URLs are supplied */
  githubUrl: string | null;
  liveDemoUrl: string | null;
  /** Leave empty until real verified screenshots are placed in /public/images/ */
  screenshots: { src: string; alt: LocalizedText }[];
}

export interface JourneyMilestone {
  id: string;
  title: LocalizedText;
  category: LocalizedText;
  description: LocalizedText;
}

export interface EducationEntry {
  /** Set isProvided to true once real university, department, and period details are filled in */
  isProvided: boolean;
  institution: string;
  department: string;
  degree: string;
  period: string;
  coursework: string[];
  certifications: string[];
}

export interface SiteConfig {
  ownerName: string;
  wordmark: string;
  profileImagePath: string | null;
  githubUsername: string;
  githubUrl: string;
  /** Keep null until a real LinkedIn URL is supplied */
  linkedinUrl: string | null;
  /** Keep null until a real public email address is supplied */
  email: string | null;
  /** Public contact phone number */
  phone: string | null;
  /** WhatsApp number in international digits without '+' (e.g. 8801846476919) */
  whatsappNumber: string | null;
  /** Keep null until a backend contact endpoint (e.g. Formspree) is configured */
  contactEndpoint: string | null;
  /** Set locationConfirmed to true only if owner confirms showing location publicly */
  locationConfirmed: boolean;
  locationLabel: LocalizedText;
  /** Path to real CV PDF inside public/documents/ when supplied */
  cvFilePath: string;
  /** Set to true once the real PDF file is added to public/documents/ */
  cvAvailable: boolean;
  cvUpdatedNote: LocalizedText;
}

export type AppRoute =
  | { view: 'home' }
  | { view: 'project'; slug: ProjectSlug }
  | { view: 'not-found'; path: string };

export interface ContactFormValues {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export type ContactValidationErrors = Partial<
  Record<keyof ContactFormValues, 'required' | 'invalid_email' | 'too_short'>
>;
