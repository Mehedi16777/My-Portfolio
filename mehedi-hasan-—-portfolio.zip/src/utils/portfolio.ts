import type {
  AppRoute,
  ContactFormValues,
  ContactValidationErrors,
  Language,
  ProjectData,
  ProjectSlug,
  SkillCategoryId,
  SkillItem,
  SkillUsageStatus,
} from '../types/portfolio';

const KNOWN_PROJECT_SLUGS: ProjectSlug[] = [
  'bus-ticket-reservation',
  'sagar-pahar-ai-travel-agent',
];

export function resolveRoute(pathname: string): AppRoute {
  const normalized = pathname.replace(/\/+$/, '') || '/';
  if (normalized === '/') {
    return { view: 'home' };
  }

  if (normalized.startsWith('/projects/')) {
    const slug = normalized.slice('/projects/'.length);
    if (KNOWN_PROJECT_SLUGS.includes(slug as ProjectSlug)) {
      return { view: 'project', slug: slug as ProjectSlug };
    }
  }

  return { view: 'not-found', path: pathname };
}

export function findProjectBySlug(
  projects: ProjectData[],
  slug: ProjectSlug,
): ProjectData | undefined {
  return projects.find((project) => project.slug === slug);
}

export type SkillFilter = 'all' | SkillUsageStatus;

export function filterSkills(
  skills: SkillItem[],
  filter: SkillFilter,
): SkillItem[] {
  if (filter === 'all') {
    return skills;
  }
  return skills.filter((skill) => skill.status === filter);
}

export function groupSkillsByCategory(
  skills: SkillItem[],
  categoryOrder: SkillCategoryId[],
): { category: SkillCategoryId; items: SkillItem[] }[] {
  return categoryOrder
    .map((category) => ({
      category,
      items: skills.filter((skill) => skill.category === category),
    }))
    .filter((group) => group.items.length > 0);
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function validateContactForm(
  values: ContactFormValues,
): ContactValidationErrors {
  const errors: ContactValidationErrors = {};

  if (!values.name.trim()) {
    errors.name = 'required';
  }

  const trimmedEmail = values.email.trim();
  if (!trimmedEmail) {
    errors.email = 'required';
  } else if (!EMAIL_REGEX.test(trimmedEmail)) {
    errors.email = 'invalid_email';
  }

  if (!values.subject.trim()) {
    errors.subject = 'required';
  }

  const trimmedMessage = values.message.trim();
  if (!trimmedMessage) {
    errors.message = 'required';
  } else if (trimmedMessage.length < 15) {
    errors.message = 'too_short';
  }

  return errors;
}

export function hasValidationErrors(errors: ContactValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}

export function formatContactDraft(values: ContactFormValues): string {
  return [
    `Subject: ${values.subject.trim()}`,
    `From: ${values.name.trim()} <${values.email.trim()}>`,
    '',
    values.message.trim(),
  ].join('\n');
}

export function normalizeLanguage(raw: string | null | undefined): Language {
  return raw === 'bn' ? 'bn' : 'en';
}

export function isValidExternalUrl(url: string | null | undefined): url is string {
  if (!url || typeof url !== 'string') {
    return false;
  }
  const trimmed = url.trim();
  return trimmed.startsWith('https://') || trimmed.startsWith('http://');
}

export function buildMailtoHref(
  toEmail: string,
  values: ContactFormValues,
): string {
  const subject = encodeURIComponent(values.subject.trim());
  const bodyText = [
    `Name: ${values.name.trim()}`,
    `Reply-To: ${values.email.trim()}`,
    '',
    values.message.trim(),
  ].join('\n');
  return `mailto:${encodeURIComponent(toEmail.trim())}?subject=${subject}&body=${encodeURIComponent(bodyText)}`;
}

export function buildPhoneHref(phone: string): string {
  const digits = phone.replace(/[^\d+]/g, '');
  if (digits.startsWith('01') && digits.length === 11) {
    return `tel:+88${digits}`;
  }
  return `tel:${digits}`;
}

export function buildWhatsAppHref(
  whatsappNumber: string,
  values?: ContactFormValues,
): string {
  const digits = whatsappNumber.replace(/\D/g, '');
  const base = `https://wa.me/${digits}`;
  if (!values) {
    return base;
  }
  const text = [
    `Hello Mehedi,`,
    `Name: ${values.name.trim()}`,
    `Email: ${values.email.trim()}`,
    `Subject: ${values.subject.trim()}`,
    '',
    values.message.trim(),
  ].join('\n');
  return `${base}?text=${encodeURIComponent(text)}`;
}

export function calculateCardTilt(
  normalizedX: number,
  normalizedY: number,
  maxTiltDeg = 7,
): { rotateX: number; rotateY: number; glowX: number; glowY: number } {
  const clampedX = Math.max(-1, Math.min(1, normalizedX));
  const clampedY = Math.max(-1, Math.min(1, normalizedY));
  return {
    rotateX: Number((-clampedY * maxTiltDeg).toFixed(2)) || 0,
    rotateY: Number((clampedX * maxTiltDeg).toFixed(2)) || 0,
    glowX: Math.round(((clampedX + 1) / 2) * 100),
    glowY: Math.round(((clampedY + 1) / 2) * 100),
  };
}
