import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildMailtoHref,
  buildPhoneHref,
  buildWhatsAppHref,
  calculateCardTilt,
  filterSkills,
  findProjectBySlug,
  formatContactDraft,
  groupSkillsByCategory,
  hasValidationErrors,
  isValidExternalUrl,
  normalizeLanguage,
  resolveRoute,
  validateContactForm,
} from './portfolio';
import { skillsData, skillCategoryOrder } from '../data/skills';
import { projectsData } from '../data/projects';

test('resolveRoute handles root, valid case studies, trailing slashes, and 404 paths', () => {
  assert.deepEqual(resolveRoute('/'), { view: 'home' });
  assert.deepEqual(resolveRoute(''), { view: 'home' });
  assert.deepEqual(resolveRoute('/projects/bus-ticket-reservation'), {
    view: 'project',
    slug: 'bus-ticket-reservation',
  });
  assert.deepEqual(resolveRoute('/projects/sagar-pahar-ai-travel-agent/'), {
    view: 'project',
    slug: 'sagar-pahar-ai-travel-agent',
  });
  assert.deepEqual(resolveRoute('/projects/unknown-slug'), {
    view: 'not-found',
    path: '/projects/unknown-slug',
  });
  assert.deepEqual(resolveRoute('/about-me-fake'), {
    view: 'not-found',
    path: '/about-me-fake',
  });
});

test('findProjectBySlug returns matching project data', () => {
  const sagarPahar = findProjectBySlug(projectsData, 'sagar-pahar-ai-travel-agent');
  assert.ok(sagarPahar);
  assert.equal(sagarPahar.title, 'Sagar–Pahar AI Travel Agent');
  assert.equal(sagarPahar.stage, 'concept_prototype');
});

test('filterSkills and groupSkillsByCategory preserve supplied categories cleanly', () => {
  const all = filterSkills(skillsData, 'all');
  assert.equal(all.length, 8);

  const used = filterSkills(skillsData, 'used');
  const learning = filterSkills(skillsData, 'learning');
  assert.ok(used.every((s) => s.status === 'used'));
  assert.ok(learning.every((s) => s.status === 'learning'));
  assert.equal(used.length + learning.length, skillsData.length);

  const grouped = groupSkillsByCategory(all, skillCategoryOrder);
  assert.deepEqual(
    grouped.map((g) => g.category),
    ['programming', 'frontend', 'backend', 'ai_ml'],
  );
});

test('validateContactForm enforces required fields, email format, and message length', () => {
  const emptyErrors = validateContactForm({
    name: '  ',
    email: '',
    subject: '',
    message: '',
  });
  assert.equal(hasValidationErrors(emptyErrors), true);
  assert.equal(emptyErrors.name, 'required');
  assert.equal(emptyErrors.email, 'required');
  assert.equal(emptyErrors.subject, 'required');
  assert.equal(emptyErrors.message, 'required');

  const invalidEmailAndShort = validateContactForm({
    name: 'Amina',
    email: 'not-an-email',
    subject: 'Collaboration',
    message: 'Too short',
  });
  assert.equal(invalidEmailAndShort.email, 'invalid_email');
  assert.equal(invalidEmailAndShort.message, 'too_short');

  const valid = validateContactForm({
    name: 'Amina',
    email: 'amina@example.com',
    subject: 'Project Inquiry',
    message: 'Hello Mehedi, I enjoyed reviewing your Sagar-Pahar concept.',
  });
  assert.equal(hasValidationErrors(valid), false);
});

test('formatContactDraft, normalizeLanguage, and isValidExternalUrl work reliably', () => {
  const draft = formatContactDraft({
    name: 'Rahim',
    email: 'rahim@example.com',
    subject: 'Hello',
    message: 'Interested in connecting regarding AI projects.',
  });
  assert.match(draft, /^Subject: Hello/);
  assert.match(draft, /From: Rahim <rahim@example\.com>/);

  assert.equal(normalizeLanguage('bn'), 'bn');
  assert.equal(normalizeLanguage('en'), 'en');
  assert.equal(normalizeLanguage('fr'), 'en');
  assert.equal(normalizeLanguage(null), 'en');

  assert.equal(isValidExternalUrl('https://github.com/Mehedi16777'), true);
  assert.equal(isValidExternalUrl(null), false);
  assert.equal(isValidExternalUrl(''), false);
  assert.equal(isValidExternalUrl('javascript:alert(1)'), false);
});

test('buildMailtoHref, buildPhoneHref, buildWhatsAppHref, and calculateCardTilt produce safe outputs', () => {
  const href = buildMailtoHref('mehedihasanbasher@gmail.com', {
    name: 'Nadia',
    email: 'nadia@example.com',
    subject: 'AI Portfolio',
    message: 'Great work on Sagar-Pahar AI Travel Agent.',
  });
  assert.ok(href.startsWith('mailto:mehedihasanbasher%40gmail.com?'));
  assert.match(href, /subject=AI%20Portfolio/);
  assert.match(href, /Reply-To%3A%20nadia%40example\.com/);

  assert.equal(buildPhoneHref('01846476919'), 'tel:+8801846476919');
  assert.equal(buildWhatsAppHref('8801846476919'), 'https://wa.me/8801846476919');
  const waWithMsg = buildWhatsAppHref('8801846476919', {
    name: 'Nadia',
    email: 'nadia@example.com',
    subject: 'AI Portfolio',
    message: 'Great work on Sagar-Pahar AI Travel Agent.',
  });
  assert.ok(waWithMsg.startsWith('https://wa.me/8801846476919?text='));
  assert.match(waWithMsg, /AI%20Portfolio/);

  const center = calculateCardTilt(0, 0, 8);
  assert.deepEqual(center, { rotateX: 0, rotateY: 0, glowX: 50, glowY: 50 });

  const corner = calculateCardTilt(2, -2, 6);
  assert.deepEqual(corner, { rotateX: 6, rotateY: 6, glowX: 100, glowY: 0 });
});

import { siteConfig } from '../data/site';
import { educationEntry } from '../data/journey';

test('siteConfig CV PDF and verified academic credentials are properly configured', () => {
  assert.equal(siteConfig.cvAvailable, true);
  assert.equal(siteConfig.cvFilePath, '/assets/aistudio/Mehedi_Hasan_CV_4a6600e4.pdf');
  assert.equal(educationEntry.isProvided, true);
  assert.match(educationEntry.institution, /Daffodil International University/);
  assert.match(educationEntry.degree, /B\.Sc\. in Software Engineering/);
});

