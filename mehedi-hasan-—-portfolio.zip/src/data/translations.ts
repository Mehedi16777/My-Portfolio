import type { Language, SkillCategoryId } from '../types/portfolio';

export interface TranslationDictionary {
  nav: {
    about: string;
    skills: string;
    projects: string;
    journey: string;
    contact: string;
    menuOpen: string;
    menuClose: string;
    skipToContent: string;
  };
  hero: {
    eyebrow: string;
    headline: string;
    subtitle: string;
    introduction: string;
    primaryCta: string;
    secondaryCtaReady: string;
    secondaryCtaFallback: string;
    githubLabel: string;
    linkedinLabel: string;
    snapshotLabel: string;
    focusItems: { label: string; value: string }[];
  };
  about: {
    kicker: string;
    heading: string;
    lead: string;
    paragraphs: string[];
    highlights: { title: string; body: string }[];
  };
  skills: {
    kicker: string;
    heading: string;
    lead: string;
    filterAll: string;
    filterUsed: string;
    filterLearning: string;
    statusUsed: string;
    statusLearning: string;
    categories: Record<SkillCategoryId, string>;
    emptyFilter: string;
  };
  projects: {
    kicker: string;
    heading: string;
    lead: string;
    viewCaseStudy: string;
    githubLink: string;
    liveDemoLink: string;
    stackPending: string;
    destinationsLabel: string;
  };
  caseStudy: {
    backToPortfolio: string;
    overview: string;
    problem: string;
    targetUsers: string;
    proposedSolution: string;
    agenticWorkflow: string;
    implementedTitle: string;
    plannedTitle: string;
    technologiesTitle: string;
    contributionTitle: string;
    challengesTitle: string;
    screenshotsTitle: string;
    screenshotsEmpty: string;
    linksTitle: string;
    linksPending: string;
    destinationsTitle: string;
    prototypeNotice: string;
  };
  journey: {
    kicker: string;
    heading: string;
    lead: string;
    academicLabel: string;
    academicPendingTitle: string;
    academicPendingBody: string;
    tracksHeading: string;
    courseworkLabel: string;
    certificationsLabel: string;
  };
  interests: {
    kicker: string;
    heading: string;
    lead: string;
    items: { title: string; description: string }[];
  };
  github: {
    kicker: string;
    heading: string;
    lead: string;
    visitProfile: string;
    loadingRepos: string;
    reposHeading: string;
    noDescription: string;
    apiFallbackTitle: string;
    apiFallbackBody: string;
    publicReposLabel: string;
    followersLabel: string;
    updatedLabel: string;
  };
  resume: {
    kicker: string;
    heading: string;
    lead: string;
    downloadButton: string;
    openPdfButton: string;
    previewButton: string;
    hidePreviewButton: string;
    documentMeta: string;
    cvSummaryLabel: string;
    cvSummaryBody: string;
    educationHeading: string;
    courseworkLabel: string;
    cvProjectsHeading: string;
    technicalStackHeading: string;
    extracurricularLabel: string;
    languagesLabel: string;
    locationLabel: string;
    pendingTitle: string;
    pendingBody: string;
    profileSummaryTitle: string;
    summaryRole: string;
    summarySkillsLabel: string;
    summaryProjectsLabel: string;
  };
  contact: {
    kicker: string;
    heading: string;
    lead: string;
    nameLabel: string;
    namePlaceholder: string;
    emailLabel: string;
    emailPlaceholder: string;
    subjectLabel: string;
    subjectPlaceholder: string;
    messageLabel: string;
    messagePlaceholder: string;
    submitButton: string;
    submitButtonDraft: string;
    openEmailAppButton: string;
    openWhatsAppButton: string;
    copyDraftButton: string;
    copiedFeedback: string;
    directChannelsTitle: string;
    phoneLabel: string;
    whatsappLabel: string;
    whatsappChatCta: string;
    emailPendingNote: string;
    draftModeNotice: string;
    draftReadyTitle: string;
    draftReadyBody: string;
    draftReadyWithEmailBody: string;
    errors: {
      required: string;
      invalid_email: string;
      too_short: string;
    };
  };
  footer: {
    statement: string;
    backToTop: string;
    rights: string;
  };
  notFound: {
    code: string;
    heading: string;
    body: string;
    backHome: string;
  };
}

export const translations: Record<Language, TranslationDictionary> = {
  en: {
    nav: {
      about: 'About',
      skills: 'Skills',
      projects: 'Projects',
      journey: 'Journey',
      contact: 'Contact',
      menuOpen: 'Open navigation menu',
      menuClose: 'Close navigation menu',
      skipToContent: 'Skip to main content',
    },
    hero: {
      eyebrow: 'Software Engineering · AI · Technology',
      headline: 'Building ideas into meaningful digital experiences.',
      subtitle: 'Software Engineering Student | Aspiring Software Developer | AI Enthusiast',
      introduction:
        "I'm Mehedi Hasan, a software engineering student and aspiring developer passionate about software development, artificial intelligence, and building useful digital products.",
      primaryCta: 'Explore Projects',
      secondaryCtaReady: 'Download CV',
      secondaryCtaFallback: 'Resume & CV',
      githubLabel: 'GitHub',
      linkedinLabel: 'LinkedIn',
      snapshotLabel: 'Profile Focus',
      focusItems: [
        { label: 'Role', value: 'Student & Aspiring Developer' },
        { label: 'Core Focus', value: 'Software Engineering & AI' },
        { label: 'Featured Concepts', value: '2 Documented Projects' },
      ],
    },
    about: {
      kicker: 'About Me',
      heading: 'Curiosity turned into structured engineering.',
      lead: 'Learning the craft of software development step by step—balancing clean interfaces, sound logic, and practical AI ideas.',
      paragraphs: [
        'As a software engineering student, I enjoy breaking complex everyday problems down into clear, dependable software flows. Whether structuring a reservation system or mapping out how an intelligent travel assistant should reason about a trip, I care about clarity for the end user.',
        'My current learning centers on modern web engineering with React, Next.js, and Node.js alongside Python and foundational artificial intelligence concepts. Outside coursework and personal builds, I spend time studying how agentic AI workflows can assist real-world tasks responsibly.',
      ],
      highlights: [
        {
          title: 'Problem Solving First',
          body: 'Starting from real user friction before choosing frameworks or interfaces.',
        },
        {
          title: 'Software Craft',
          body: 'Writing modular, readable TypeScript and Python with attention to edge cases.',
        },
        {
          title: 'Applied AI Exploration',
          body: 'Designing practical multi-step AI concepts grounded in real constraints.',
        },
      ],
    },
    skills: {
      kicker: 'Technical Toolkit',
      heading: 'Skills & Technologies',
      lead: 'Technologies I work with directly alongside areas I am actively studying—presented transparently without inflated proficiency scores.',
      filterAll: 'All',
      filterUsed: 'Used in Builds',
      filterLearning: 'Currently Learning',
      statusUsed: 'Practiced',
      statusLearning: 'Learning',
      categories: {
        programming: 'Programming',
        frontend: 'Frontend',
        backend: 'Backend',
        ai_ml: 'AI & Machine Learning',
      },
      emptyFilter: 'No skills match the selected filter.',
    },
    projects: {
      kicker: 'Selected Work',
      heading: 'Featured Projects',
      lead: 'Real academic builds and thoughtfully scoped product concepts, clearly distinguishing implemented work from planned capabilities.',
      viewCaseStudy: 'View Case Study',
      githubLink: 'GitHub Repository',
      liveDemoLink: 'Live Demo',
      stackPending: 'Stack tags awaiting confirmation in project data',
      destinationsLabel: 'Concept Destinations',
    },
    caseStudy: {
      backToPortfolio: 'Back to Portfolio',
      overview: 'Project Overview',
      problem: 'Problem Statement',
      targetUsers: 'Target Users',
      proposedSolution: 'Proposed Solution',
      agenticWorkflow: 'Agentic AI Workflow Architecture',
      implementedTitle: 'Current Scope & Implemented Elements',
      plannedTitle: 'Planned Features & Roadmap',
      technologiesTitle: 'Technology Stack',
      contributionTitle: 'Role & Contribution',
      challengesTitle: 'Challenges & Key Learning',
      screenshotsTitle: 'Product Visuals & Screenshots',
      screenshotsEmpty:
        'Screenshots have not been supplied yet. Add verified images in public/images/ and reference them in src/data/projects.ts.',
      linksTitle: 'Project Links',
      linksPending: 'Repository and live demo links will appear here once supplied.',
      destinationsTitle: 'Target Destinations in Bangladesh',
      prototypeNotice:
        'This project is documented as a concept and prototype. Live booking integrations and real-time availability are planned future phases, not active claims.',
    },
    journey: {
      kicker: 'Education & Journey',
      heading: 'Learning Path & Academic Profile',
      lead: 'A transparent view of my ongoing software engineering studies and self-directed technical tracks.',
      academicLabel: 'Formal Education',
      academicPendingTitle: 'Academic details ready to be configured',
      academicPendingBody:
        'University, department, academic year, and coursework entries are intentionally left hidden until real verified details are added in src/data/journey.ts.',
      tracksHeading: 'Current Learning Tracks',
      courseworkLabel: 'Relevant Coursework',
      certificationsLabel: 'Certifications',
    },
    interests: {
      kicker: 'Interests',
      heading: 'What I Enjoy Exploring',
      lead: 'Core areas where I invest my study time and curiosity.',
      items: [
        {
          title: 'Software Development',
          description: 'Turning clear requirements into maintainable, user-friendly applications.',
        },
        {
          title: 'Artificial Intelligence',
          description: 'Understanding agentic planning, structured reasoning, and helpful automation.',
        },
        {
          title: 'Machine Learning',
          description: 'Studying data-driven modeling fundamentals and real-world evaluation.',
        },
        {
          title: 'Problem Solving',
          description: 'Decomposing tricky logic, edge cases, and system workflows step by step.',
        },
        {
          title: 'Exploring New Technologies',
          description: 'Testing modern web tools and keeping pace with practical engineering patterns.',
        },
      ],
    },
    github: {
      kicker: 'Open Source & Code',
      heading: 'GitHub Activity',
      lead: 'Explore my public profile and repositories directly on GitHub.',
      visitProfile: 'Visit @Mehedi16777 on GitHub',
      loadingRepos: 'Fetching public repositories from GitHub...',
      reposHeading: 'Public Repositories',
      noDescription: 'No repository description provided yet.',
      apiFallbackTitle: 'Live GitHub preview unavailable',
      apiFallbackBody:
        'Public GitHub API data could not be loaded right now (rate limit or offline environment). You can still browse repositories directly on GitHub.',
      publicReposLabel: 'Public Repos',
      followersLabel: 'Followers',
      updatedLabel: 'Updated',
    },
    resume: {
      kicker: 'Curriculum Vitae',
      heading: 'Resume / CV',
      lead: 'Downloadable PDF access, inline document preview, and verified academic & data science overview.',
      downloadButton: 'Download CV (PDF)',
      openPdfButton: 'Open PDF',
      previewButton: 'Preview PDF Inline',
      hidePreviewButton: 'Hide PDF Preview',
      documentMeta: 'Mehedi_Hasan_CV.pdf · 1 Page PDF',
      cvSummaryLabel: 'Professional Summary',
      cvSummaryBody:
        'Software Engineering student at Daffodil International University (CGPA 3.53 / 4.00) with a strong interest in data science. Hands-on with Python, SQL, and machine learning workflows, including data cleaning, modeling, and evaluation. Seeking an internship or entry-level role to turn data into clear, useful insights.',
      educationHeading: 'Education',
      courseworkLabel: 'Relevant Coursework',
      cvProjectsHeading: 'Data Science & ML Projects (CV)',
      technicalStackHeading: 'CV Technical Stack',
      extracurricularLabel: 'Extracurricular Activities',
      languagesLabel: 'Languages',
      locationLabel: 'Location',
      pendingTitle: 'CV PDF not uploaded yet',
      pendingBody:
        'A real CV file has not been attached yet, so no broken download link is shown. Once you add your PDF to public/documents/mehedi-hasan-cv.pdf and enable it in src/data/site.ts, the download button activates automatically.',
      profileSummaryTitle: 'Verified Profile Snapshot',
      summaryRole: 'Software Engineering Student · Data Science Enthusiast · AI Enthusiast',
      summarySkillsLabel: 'Core Portfolio Skills',
      summaryProjectsLabel: 'Featured Portfolio Projects',
    },
    contact: {
      kicker: 'Get in Touch',
      heading: 'Contact',
      lead: 'Have a question, project idea, or opportunity to discuss? Validate your message below or connect through GitHub.',
      nameLabel: 'Full Name',
      namePlaceholder: 'Your name',
      emailLabel: 'Email Address',
      emailPlaceholder: 'you@example.com',
      subjectLabel: 'Subject',
      subjectPlaceholder: 'What would you like to discuss?',
      messageLabel: 'Message',
      messagePlaceholder: 'Write your message here...',
      submitButton: 'Send Message',
      submitButtonDraft: 'Prepare Message Draft',
      openEmailAppButton: 'Open in Email App',
      openWhatsAppButton: 'Send via WhatsApp',
      copyDraftButton: 'Copy Message Draft',
      copiedFeedback: 'Message draft copied to clipboard',
      directChannelsTitle: 'Direct Channels',
      phoneLabel: 'Phone',
      whatsappLabel: 'WhatsApp',
      whatsappChatCta: 'Chat on WhatsApp',
      emailPendingNote:
        'Direct email address is not published yet. Add your email in src/data/site.ts when ready.',
      draftModeNotice:
        'No server mail relay is configured on this static site—validate your message below to open it in your email app, WhatsApp, or copy the draft.',
      draftReadyTitle: 'Validated Message Ready',
      draftReadyBody:
        'Your inputs passed validation. Copy your prepared draft below or reach out via GitHub.',
      draftReadyWithEmailBody:
        'Your message is validated. Open it directly in your email client, send via WhatsApp, or copy the draft below.',
      errors: {
        required: 'This field is required.',
        invalid_email: 'Please enter a valid email address.',
        too_short: 'Please write at least 15 characters so your message is clear.',
      },
    },
    footer: {
      statement: 'Software Engineering Student & Aspiring Developer building thoughtful web and AI experiences.',
      backToTop: 'Back to top',
      rights: 'All rights reserved.',
    },
    notFound: {
      code: '404',
      heading: 'Page not found',
      body: 'The page or case study route you requested does not exist on this portfolio.',
      backHome: 'Return to Portfolio',
    },
  },
  bn: {
    nav: {
      about: 'পরিচিতি',
      skills: 'দক্ষতা',
      projects: 'প্রজেক্ট',
      journey: 'যাত্রা',
      contact: 'যোগাযোগ',
      menuOpen: 'নেভিগেশন মেনু খুলুন',
      menuClose: 'নেভিগেশন মেনু বন্ধ করুন',
      skipToContent: 'মূল বিষয়বস্তুতে যান',
    },
    hero: {
      eyebrow: 'সফটওয়্যার ইঞ্জিনিয়ারিং · AI · প্রযুক্তি',
      headline: 'ধারণাকে অর্থবহ ডিজিটাল অভিজ্ঞতায় রূপ দেওয়া।',
      subtitle: 'সফটওয়্যার ইঞ্জিনিয়ারিং শিক্ষার্থী | উদীয়মান সফটওয়্যার ডেভেলপার | AI অনুরাগী',
      introduction:
        'আমি মেহেদী হাসান—একজন সফটওয়্যার ইঞ্জিনিয়ারিং শিক্ষার্থী ও উদীয়মান ডেভেলপার। সফটওয়্যার ডেভেলপমেন্ট, কৃত্রিম বুদ্ধিমত্তা এবং কার্যকর ডিজিটাল পণ্য তৈরিতে আমার গভীর আগ্রহ রয়েছে।',
      primaryCta: 'প্রজেক্ট দেখুন',
      secondaryCtaReady: 'সিভি ডাউনলোড করুন',
      secondaryCtaFallback: 'রেজুমে ও সিভি',
      githubLabel: 'GitHub',
      linkedinLabel: 'LinkedIn',
      snapshotLabel: 'প্রোফাইল সারসংক্ষেপ',
      focusItems: [
        { label: 'পরিচয়', value: 'শিক্ষার্থী ও উদীয়মান ডেভেলপার' },
        { label: 'মূল আগ্রহ', value: 'সফটওয়্যার ইঞ্জিনিয়ারিং ও AI' },
        { label: 'নির্বাচিত কাজ', value: '২টি নথিভুক্ত প্রজেক্ট' },
      ],
    },
    about: {
      kicker: 'আমার সম্পর্কে',
      heading: 'কৌতূহল থেকে কাঠামোবদ্ধ সফটওয়্যার প্রকৌশল।',
      lead: 'ধাপে ধাপে সফটওয়্যার ডেভেলপমেন্টের কারিগরি শেখা—পরিচ্ছন্ন ইন্টারফেস, নির্ভরযোগ্য যুক্তি ও বাস্তবসম্মত AI ধারণার সমন্বয়।',
      paragraphs: [
        'সফটওয়্যার ইঞ্জিনিয়ারিংয়ের একজন শিক্ষার্থী হিসেবে আমি দৈনন্দিন জটিল সমস্যাগুলোকে স্পষ্ট ও নির্ভরযোগ্য সফটওয়্যার প্রবাহে ভাগ করতে ভালোবাসি। টিকিট রিজার্ভেশন ব্যবস্থা গঠন করা হোক কিংবা একটি বুদ্ধিমান ভ্রমণ সহায়কের কর্মপদ্ধতি নকশা করা—ব্যবহারকারীর জন্য সহজবোধ্যতাই আমার মূল লক্ষ্য।',
        'বর্তমানে আমি আধুনিক ওয়েব প্রযুক্তি—React, Next.js ও Node.js-এর পাশাপাশি Python এবং কৃত্রিম বুদ্ধিমত্তার মৌলিক বিষয়গুলো চর্চা করছি। একাডেমিক কাজের বাইরে এজেন্টিক AI ওয়ার্কফ্লো কীভাবে বাস্তব সমস্যা সমাধানে সহায়তা করতে পারে তা নিয়ে নিয়মিত অন্বেষণ করি।',
      ],
      highlights: [
        {
          title: 'সমস্যা সমাধানই প্রথম',
          body: 'প্রযুক্তি বাছাইয়ের আগে ব্যবহারকারীর প্রকৃত প্রয়োজন ও প্রতিবন্ধকতা বোঝা।',
        },
        {
          title: 'পরিচ্ছন্ন কোড চর্চা',
          body: 'TypeScript ও Python-এ মডুলার, পাঠযোগ্য কোড ও সম্ভাব্য সীমাবদ্ধতা বিবেচনা।',
        },
        {
          title: 'বাস্তবধর্মী AI অন্বেষণ',
          body: 'বাস্তব সীমাবদ্ধতার মধ্যে থেকে বহু-ধাপের AI ওয়ার্কফ্লো ধারণা তৈরি।',
        },
      ],
    },
    skills: {
      kicker: 'প্রযুক্তিগত দক্ষতা',
      heading: 'দক্ষতা ও প্রযুক্তিসমূহ',
      lead: 'যে প্রযুক্তিগুলোতে সরাসরি কাজ করেছি এবং যেগুলো বর্তমানে শিখছি—কোনো অতিরঞ্জিত শতাংশ ছাড়াই স্বচ্ছ উপস্থাপন।',
      filterAll: 'সবগুলো',
      filterUsed: 'কাজে ব্যবহৃত',
      filterLearning: 'বর্তমানে শিখছি',
      statusUsed: 'ব্যবহৃত',
      statusLearning: 'শিক্ষাধীন',
      categories: {
        programming: 'প্রোগ্রামিং',
        frontend: 'ফ্রন্টএন্ড',
        backend: 'ব্যাকএন্ড',
        ai_ml: 'AI ও মেশিন লার্নিং',
      },
      emptyFilter: 'নির্বাচিত ফিল্টারে কোনো দক্ষতা পাওয়া যায়নি।',
    },
    projects: {
      kicker: 'নির্বাচিত কাজ',
      heading: 'উল্লেখযোগ্য প্রজেক্টসমূহ',
      lead: 'ব্যবহারিক প্রজেক্ট ও সুচিন্তিত পণ্যের ধারণা—যেখানে সম্পন্ন অংশ এবং পরিকল্পিত বৈশিষ্ট্য স্পষ্টভাবে আলাদা করা হয়েছে।',
      viewCaseStudy: 'কেস স্টাডি দেখুন',
      githubLink: 'GitHub রিপোজিটরি',
      liveDemoLink: 'লাইভ ডেমো',
      stackPending: 'প্রযুক্তি স্ট্যাক তথ্য নিশ্চিত হলে এখানে যুক্ত হবে',
      destinationsLabel: 'পরিকল্পিত গন্তব্য',
    },
    caseStudy: {
      backToPortfolio: 'পোর্টফোলিওতে ফিরে যান',
      overview: 'প্রজেক্ট সংক্ষিপ্ত বিবরণ',
      problem: 'সমস্যার প্রেক্ষাপট',
      targetUsers: 'লক্ষ্যমাত্রা ব্যবহারকারী',
      proposedSolution: 'প্রস্তাবিত সমাধান',
      agenticWorkflow: 'এজেন্টিক AI ওয়ার্কফ্লো কাঠামো',
      implementedTitle: 'বর্তমান পরিধি ও কার্যকর অংশ',
      plannedTitle: 'পরিকল্পিত বৈশিষ্ট্য ও রোডম্যাপ',
      technologiesTitle: 'প্রযুক্তি স্ট্যাক',
      contributionTitle: 'ভূমিকা ও অবদান',
      challengesTitle: 'চ্যালেঞ্জ ও শিক্ষা',
      screenshotsTitle: 'প্রজেক্টের দৃশ্য ও স্ক্রিনশট',
      screenshotsEmpty:
        'এখনো কোনো স্ক্রিনশট যুক্ত করা হয়নি। যাচাইকৃত ছবি public/images/-এ রেখে src/data/projects.ts-এ যুক্ত করুন।',
      linksTitle: 'প্রজেক্ট লিংক',
      linksPending: 'রিপোজিটরি ও লাইভ ডেমো লিংক যুক্ত করা হলে এখানে দেখা যাবে।',
      destinationsTitle: 'বাংলাদেশের নির্ধারিত গন্তব্যসমূহ',
      prototypeNotice:
        'এই প্রজেক্টটি একটি কনসেপ্ট ও প্রোটোটাইপ হিসেবে উপস্থাপিত। লাইভ বুকিং ও তাৎক্ষণিক প্রাপ্যতা ভবিষ্যৎ পরিকল্পনার অংশ—বর্তমানে চালু সেবা নয়।',
    },
    journey: {
      kicker: 'শিক্ষা ও যাত্রা',
      heading: 'শেখার পথ ও একাডেমিক পরিচিতি',
      lead: 'সফটওয়্যার ইঞ্জিনিয়ারিং অধ্যয়ন এবং স্ব-উদ্যোগে প্রযুক্তি শেখার স্বচ্ছ চিত্র।',
      academicLabel: 'প্রাতিষ্ঠানিক শিক্ষা',
      academicPendingTitle: 'একাডেমিক তথ্য যুক্ত করার জন্য প্রস্তুত',
      academicPendingBody:
        'বিশ্ববিদ্যালয়, বিভাগ, শিক্ষাবর্ষ ও কোর্সওয়ার্কের তথ্য যাচাইকৃতভাবে src/data/journey.ts-এ যুক্ত না করা পর্যন্ত গোপন রাখা হয়েছে।',
      tracksHeading: 'বর্তমান শেখার ক্ষেত্রসমূহ',
      courseworkLabel: 'সংশ্লিষ্ট কোর্সসমূহ',
      certificationsLabel: 'সার্টিফিকেশন',
    },
    interests: {
      kicker: 'আগ্রহের ক্ষেত্র',
      heading: 'যা নিয়ে কাজ করতে ভালোবাসি',
      lead: 'যে বিষয়গুলোতে আমি নিয়মিত সময় ও কৌতূহল ব্যয় করি।',
      items: [
        {
          title: 'সফটওয়্যার ডেভেলপমেন্ট',
          description: 'স্পষ্ট চাহিদাকে রক্ষণাবেক্ষণযোগ্য ও ব্যবহারবান্ধব অ্যাপ্লিকেশনে রূপ দেওয়া।',
        },
        {
          title: 'কৃত্রিম বুদ্ধিমত্তা (AI)',
          description: 'এজেন্টিক পরিকল্পনা, কাঠামোবদ্ধ বিশ্লেষণ ও সহায়ক অটোমেশন নিয়ে জানা।',
        },
        {
          title: 'মেশিন লার্নিং',
          description: 'ডেটা-নির্ভর মডেলিংয়ের মূলনীতি ও বাস্তব প্রয়োগের মূল্যায়ন শেখা।',
        },
        {
          title: 'সমস্যা সমাধান',
          description: 'জটিল লজিক, এজ-কেস ও সিস্টেম প্রবাহ ধাপে ধাপে বিশ্লেষণ করা।',
        },
        {
          title: 'নতুন প্রযুক্তি অন্বেষণ',
          description: 'আধুনিক ওয়েব টুল পরীক্ষা করা এবং কার্যকর প্রকৌশল ধারণার সাথে তাল মিলিয়ে চলা।',
        },
      ],
    },
    github: {
      kicker: 'ওপেন সোর্স ও কোড',
      heading: 'GitHub প্রোফাইল ও কোড',
      lead: 'সরাসরি GitHub-এ আমার প্রোফাইল এবং পাবলিক রিপোজিটরিগুলো দেখুন।',
      visitProfile: 'GitHub-এ @Mehedi16777 দেখুন',
      loadingRepos: 'GitHub থেকে পাবলিক রিপোজিটরি তথ্য আনা হচ্ছে...',
      reposHeading: 'পাবলিক রিপোজিটরি',
      noDescription: 'এখনো কোনো বিবরণ যুক্ত করা হয়নি।',
      apiFallbackTitle: 'লাইভ GitHub প্রিভিউ এই মুহূর্তে পাওয়া যাচ্ছে না',
      apiFallbackBody:
        'API রেট লিমিট বা নেটওয়ার্ক সীমাবদ্ধতার কারণে লাইভ ডেটা লোড করা যায়নি। তবে আপনি সরাসরি GitHub প্রোফাইলে গিয়ে সব কোড দেখতে পারেন।',
      publicReposLabel: 'পাবলিক রিপো',
      followersLabel: 'অনুসারী',
      updatedLabel: 'হালনাগাদ',
    },
    resume: {
      kicker: 'জীবনবৃত্তান্ত',
      heading: 'রেজুমে / সিভি',
      lead: 'সরাসরি PDF ডাউনলোড, ইনলাইন নথি প্রিভিউ এবং যাচাইকৃত একাডেমিক ও ডেটা সায়েন্স পরিচিতি।',
      downloadButton: 'সিভি ডাউনলোড (PDF)',
      openPdfButton: 'PDF খুলুন',
      previewButton: 'পৃষ্ঠায় PDF দেখুন',
      hidePreviewButton: 'প্রিভিউ লুকান',
      documentMeta: 'Mehedi_Hasan_CV.pdf · ১ পৃষ্ঠার PDF',
      cvSummaryLabel: 'পেশাগত সারসংক্ষেপ',
      cvSummaryBody:
        'ড্যাফোডিল ইন্টারন্যাশনাল ইউনিভার্সিটির সফটওয়্যার ইঞ্জিনিয়ারিং শিক্ষার্থী (CGPA 3.53 / 4.00) এবং ডেটা সায়েন্স অনুরাগী। Python, SQL এবং ডেটা ক্লিনিং, মডেলিং ও মূল্যায়নসহ মেশিন লার্নিং ওয়ার্কফ্লোতে হাতে-কলমে অভিজ্ঞতা রয়েছে। ডেটা থেকে স্পষ্ট ও কার্যকর সিদ্ধান্ত তুলে ধরতে ইন্টার্নশিপ বা এন্ট্রি-লেভেল ভূমিকার সন্ধানে আছি।',
      educationHeading: 'শিক্ষাগত যোগ্যতা',
      courseworkLabel: 'সংশ্লিষ্ট কোর্সসমূহ',
      cvProjectsHeading: 'ডেটা সায়েন্স ও ML প্রজেক্ট (সিভি)',
      technicalStackHeading: 'সিভি প্রযুক্তি স্ট্যাক',
      extracurricularLabel: 'সহশিক্ষা কার্যক্রম',
      languagesLabel: 'ভাষা দক্ষতা',
      locationLabel: 'অবস্থান',
      pendingTitle: 'সিভি PDF এখনো যুক্ত করা হয়নি',
      pendingBody:
        'আসল সিভি ফাইল এখনো যুক্ত না থাকায় কোনো অকার্যকর ডাউনলোড বাটন রাখা হয়নি। public/documents/mehedi-hasan-cv.pdf ফাইলে PDF রেখে src/data/site.ts-এ সক্রিয় করলে ডাউনলোড বাটন স্বয়ংক্রিয়ভাবে চালু হবে।',
      profileSummaryTitle: 'যাচাইকৃত প্রোফাইল সারসংক্ষেপ',
      summaryRole: 'সফটওয়্যার ইঞ্জিনিয়ারিং শিক্ষার্থী · ডেটা সায়েন্স ও AI অনুরাগী',
      summarySkillsLabel: 'মূল পোর্টফোলিও দক্ষতা',
      summaryProjectsLabel: 'নির্বাচিত পোর্টফোলিও প্রজেক্ট',
    },
    contact: {
      kicker: 'যোগাযোগ করুন',
      heading: 'যোগাযোগ',
      lead: 'কোনো প্রশ্ন, প্রজেক্ট ধারণা বা আলোচনার বিষয় থাকলে নিচের ফর্মে বার্তা যাচাই করুন অথবা GitHub-এ যুক্ত হোন।',
      nameLabel: 'আপনার নাম',
      namePlaceholder: 'পুরো নাম লিখুন',
      emailLabel: 'ইমেইল ঠিকানা',
      emailPlaceholder: 'you@example.com',
      subjectLabel: 'বিষয়',
      subjectPlaceholder: 'কী বিষয়ে আলোচনা করতে চান?',
      messageLabel: 'বার্তা',
      messagePlaceholder: 'আপনার বার্তা লিখুন...',
      submitButton: 'বার্তা পাঠান',
      submitButtonDraft: 'বার্তা প্রস্তুত করুন',
      openEmailAppButton: 'ইমেইল অ্যাপে খুলুন',
      openWhatsAppButton: 'WhatsApp-এ পাঠান',
      copyDraftButton: 'বার্তার খসড়া কপি করুন',
      copiedFeedback: 'বার্তার খসড়া ক্লিপবোর্ডে কপি হয়েছে',
      directChannelsTitle: 'সরাসরি মাধ্যম',
      phoneLabel: 'ফোন',
      whatsappLabel: 'WhatsApp',
      whatsappChatCta: 'WhatsApp-এ বার্তা দিন',
      emailPendingNote:
        'সরাসরি ইমেইল ঠিকানা এখনো প্রকাশিত হয়নি। প্রস্তুত হলে src/data/site.ts-এ যুক্ত করা যাবে।',
      draftModeNotice:
        'এই স্ট্যাটিক পোর্টফোলিওতে কোনো মেইল সার্ভার যুক্ত নেই—নিচে তথ্য যাচাই করে ইমেইল অ্যাপ, WhatsApp-এ খুলুন বা খসড়া কপি করুন।',
      draftReadyTitle: 'যাচাইকৃত বার্তা প্রস্তুত',
      draftReadyBody:
        'আপনার তথ্য সঠিকভাবে যাচাই হয়েছে। নিচের বাটনে ক্লিক করে খসড়াটি কপি করতে পারেন অথবা GitHub-এর মাধ্যমে যোগাযোগ করতে পারেন।',
      draftReadyWithEmailBody:
        'আপনার তথ্য সঠিকভাবে যাচাই হয়েছে। সরাসরি ইমেইল অ্যাপ বা WhatsApp-এ পাঠান অথবা খসড়া কপি করুন।',
      errors: {
        required: 'এই ঘরটি পূরণ করা আবশ্যক।',
        invalid_email: 'অনুগ্রহ করে একটি সঠিক ইমেইল ঠিকানা লিখুন।',
        too_short: 'স্পষ্টভাবে বোঝানোর জন্য অন্তত ১৫ অক্ষরের বার্তা লিখুন।',
      },
    },
    footer: {
      statement: 'সফটওয়্যার ইঞ্জিনিয়ারিং শিক্ষার্থী ও উদীয়মান ডেভেলপার—ওয়েব ও AI অভিজ্ঞতা নির্মাণে সচেষ্ট।',
      backToTop: 'উপরে ফিরে যান',
      rights: 'সর্বস্বত্ব সংরক্ষিত।',
    },
    notFound: {
      code: '৪০৪',
      heading: 'পৃষ্ঠাটি পাওয়া যায়নি',
      body: 'আপনি যে পৃষ্ঠা বা কেস স্টাডি খুঁজছেন তা এই পোর্টফোলিওতে নেই।',
      backHome: 'মূল পোর্টফোলিওতে ফিরে যান',
    },
  },
};
