import type { SkillCategoryId, SkillItem } from '../types/portfolio';

export const skillCategoryOrder: SkillCategoryId[] = [
  'programming',
  'frontend',
  'backend',
  'ai_ml',
];

/**
 * Supplied technical skills organized by category.
 * Update `status` between 'used' and 'learning' as your experience evolves.
 */
export const skillsData: SkillItem[] = [
  {
    id: 'python',
    name: 'Python',
    category: 'programming',
    status: 'used',
    note: {
      en: 'Core programming language for problem solving, scripting, and AI exploration.',
      bn: 'সমস্যা সমাধান, স্ক্রিপ্টিং এবং AI নিয়ে কাজের জন্য মূল প্রোগ্রামিং ভাষা।',
    },
  },
  {
    id: 'javascript',
    name: 'JavaScript',
    category: 'programming',
    status: 'used',
    note: {
      en: 'Interactive web logic, client-side application state, and modern ES syntax.',
      bn: 'ইন্টারঅ্যাক্টিভ ওয়েব লজিক, অ্যাপ্লিকেশন স্টেট এবং আধুনিক ES সিনট্যাক্স।',
    },
  },
  {
    id: 'html',
    name: 'HTML',
    category: 'frontend',
    status: 'used',
    note: {
      en: 'Semantic document structure, accessible markup, and responsive foundations.',
      bn: 'সিম্যান্টিক ডকুমেন্ট কাঠামো, অ্যাক্সেসিবল মার্কআপ এবং রেসপনসিভ ভিত্তি।',
    },
  },
  {
    id: 'react',
    name: 'React',
    category: 'frontend',
    status: 'used',
    note: {
      en: 'Component-driven UI architecture, hooks, and modular interface state.',
      bn: 'কম্পোনেন্ট-ভিত্তিক UI আর্কিটেকচার, হুকস এবং মডুলার ইন্টারফেস স্টেট।',
    },
  },
  {
    id: 'nextjs',
    name: 'Next.js',
    category: 'frontend',
    status: 'learning',
    note: {
      en: 'App Router patterns, structured routing, and modern full-stack web workflows.',
      bn: 'App Router প্যাটার্ন, কাঠামোবদ্ধ রাউটিং এবং আধুনিক ফুল-স্ট্যাক ওয়েব ওয়ার্কফ্লো।',
    },
  },
  {
    id: 'nodejs',
    name: 'Node.js',
    category: 'backend',
    status: 'learning',
    note: {
      en: 'Server-side JavaScript runtime, API concepts, and backend tooling.',
      bn: 'সার্ভার-সাইড JavaScript রানটাইম, API ধারণা এবং ব্যাকএন্ড টুলিং।',
    },
  },
  {
    id: 'artificial-intelligence',
    name: 'Artificial Intelligence',
    category: 'ai_ml',
    status: 'learning',
    note: {
      en: 'Agentic workflows, intelligent planning systems, and practical AI integration.',
      bn: 'এজেন্টিক ওয়ার্কফ্লো, বুদ্ধিমান পরিকল্পনা সিস্টেম এবং বাস্তবসম্মত AI সংযুক্তি।',
    },
  },
  {
    id: 'machine-learning',
    name: 'Machine Learning',
    category: 'ai_ml',
    status: 'learning',
    note: {
      en: 'Foundational concepts, model behavior, and data-driven reasoning.',
      bn: 'মৌলিক ধারণা, মডেলের আচরণ এবং ডেটা-নির্ভর বিশ্লেষণ।',
    },
  },
];
