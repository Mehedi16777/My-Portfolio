import type { SiteConfig } from '../types/portfolio';

/**
 * Central site configuration for Mehedi Hasan's portfolio.
 * Update placeholder/null fields only when real verified details are ready.
 */
export const siteConfig: SiteConfig = {
  ownerName: 'Mehedi Hasan',
  wordmark: 'MEHEDI.',
  profileImagePath: '/assets/aistudio/image_852e3278.png',
  githubUsername: 'Mehedi16777',
  githubUrl: 'https://github.com/Mehedi16777',

  // Optional external profiles — remain hidden in the UI while null
  linkedinUrl: null,

  // Direct email, phone, WhatsApp & contact endpoint
  email: 'mehedihasanbasher@gmail.com',
  phone: '01846476919',
  whatsappNumber: '8801846476919',
  contactEndpoint: null,

  // Verified location from Mehedi Hasan's CV
  locationConfirmed: true,
  locationLabel: {
    en: 'Mirpur, Dhaka, Bangladesh',
    bn: 'মিরপুর, ঢাকা, বাংলাদেশ',
  },

  // Attached verified CV PDF
  cvFilePath: '/assets/aistudio/Mehedi_Hasan_CV_4a6600e4.pdf',
  cvAvailable: true,
  cvUpdatedNote: {
    en: 'Verified 1-page CV PDF attached and ready to view or download.',
    bn: 'যাচাইকৃত ১-পৃষ্ঠার সিভি PDF যুক্ত করা হয়েছে এবং দেখার ও ডাউনলোডের জন্য প্রস্তুত।',
  },
};
