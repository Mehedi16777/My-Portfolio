import type { ProjectData } from '../types/portfolio';

/**
 * Centralized portfolio projects data.
 * Unverified repository links, live demo URLs, screenshots, and unconfirmed tech stacks
 * remain empty/null until confirmed and supplied by Mehedi Hasan.
 */
export const projectsData: ProjectData[] = [
  {
    slug: 'bus-ticket-reservation',
    title: 'Bus Ticket Reservation System',
    subtitle: {
      en: 'Structured seat booking, schedule lookup, and passenger reservation workflow',
      bn: 'সুশৃঙ্খল সিট বুকিং, সময়সূচি অনুসন্ধান এবং যাত্রী সংরক্ষণ ব্যবস্থা',
    },
    stage: 'academic_personal',
    stageLabel: {
      en: 'Project Case Study',
      bn: 'প্রজেক্ট কেস স্টাডি',
    },
    shortDescription: {
      en: 'A practical bus ticket reservation system designed to organize route selection, seat availability, and booking records in a clear user flow.',
      bn: 'রুট নির্বাচন, আসনের প্রাপ্যতা এবং বুকিং রেকর্ড স্পষ্ট ও সহজ প্রবাহে পরিচালনার জন্য তৈরি একটি ব্যবহারিক বাস টিকিট রিজার্ভেশন সিস্টেম।',
    },
    overview: {
      en: 'Built to model the core operational flow of intercity bus ticketing—from browsing routes and checking seat availability to confirming passenger reservations without manual paperwork.',
      bn: 'আন্তঃজেলা বাস টিকিটিংয়ের মূল কার্যক্রম—রুট দেখা, আসনের প্রাপ্যতা যাচাই এবং ম্যানুয়াল কাগজপত্র ছাড়া যাত্রীদের সংরক্ষণ নিশ্চিত করার প্রক্রিয়া—সুসংগঠিত করতে তৈরি।',
    },
    problemStatement: {
      en: 'Manual or fragmented ticket booking makes it difficult for travelers to verify seat availability clearly and increases scheduling errors for operators.',
      bn: 'ম্যানুয়াল বা বিচ্ছিন্ন টিকিট বুকিং প্রক্রিয়ায় যাত্রীদের জন্য আসনের প্রাপ্যতা নিশ্চিত করা কঠিন হয় এবং পরিচালনায় ভুলের ঝুঁকি বাড়ে।',
    },
    contribution: {
      en: 'Designed and structured the reservation workflow, core booking state logic, and user-facing interface flow. Specific module details can be expanded directly in src/data/projects.ts.',
      bn: 'রিজার্ভেশন ওয়ার্কফ্লো, মূল বুকিং স্টেট লজিক এবং ব্যবহারকারীর ইন্টারফেস প্রবাহ পরিকল্পনা ও গঠন করা হয়েছে। বিস্তারিত মডিউল তথ্য src/data/projects.ts থেকে যোগ করা যাবে।',
    },
    challengesAndLearning: {
      en: 'Strengthened foundational software engineering skills around input validation, preventing double-booked seats in reservation logic, and structuring clear multi-step user flows.',
      bn: 'ইনপুট যাচাইকরণ, একই আসনের দ্বৈত বুকিং প্রতিরোধের লজিক এবং ধাপে ধাপে স্পষ্ট ব্যবহারকারী প্রবাহ গঠনে সফটওয়্যার ইঞ্জিনিয়ারিং দক্ষতা দৃঢ় হয়েছে।',
    },
    implementedFeatures: [
      {
        en: 'Core bus route and trip reservation flow',
        bn: 'মূল বাস রুট ও যাত্রা সংরক্ষণ প্রবাহ',
      },
      {
        en: 'Seat selection and booking record structure',
        bn: 'আসন নির্বাচন ও বুকিং রেকর্ড কাঠামো',
      },
      {
        en: 'Structured passenger reservation input validation',
        bn: 'যাত্রী সংরক্ষণের জন্য কাঠামোবদ্ধ ইনপুট যাচাই',
      },
    ],
    plannedFeatures: [
      {
        en: 'Additional module documentation, confirmed stack tags, and screenshots when uploaded',
        bn: 'সংযুক্তির পর অতিরিক্ত মডিউল নথি, নিশ্চিতকৃত প্রযুক্তি ট্যাগ এবং স্ক্রিনশট যোগ',
      },
    ],
    confirmedTechnologies: [],
    stackNote: {
      en: 'Technology stack tags are kept blank until confirmed in src/data/projects.ts.',
      bn: 'নিশ্চিত করার আগ পর্যন্ত প্রযুক্তি স্ট্যাক ট্যাগ src/data/projects.ts-এ ফাঁকা রাখা হয়েছে।',
    },
    githubUrl: null,
    liveDemoUrl: null,
    screenshots: [],
  },
  {
    slug: 'sagar-pahar-ai-travel-agent',
    title: 'Sagar–Pahar AI Travel Agent',
    subtitle: {
      en: 'An Agentic AI-Powered Trip Planning, Ride Rental and Booking Platform',
      bn: 'এজেন্টিক AI-নির্ভর ভ্রমণ পরিকল্পনা, রাইড রেন্টাল ও বুকিং প্ল্যাটফর্মের ধারণা',
    },
    stage: 'concept_prototype',
    stageLabel: {
      en: 'Concept & Prototype',
      bn: 'কনসেপ্ট ও প্রোটোটাইপ',
    },
    shortDescription: {
      en: 'A Bangladesh-focused travel platform concept combining agentic AI trip planning, budget optimization, accommodation and transport info, and a local ride and experience marketplace.',
      bn: 'বাংলাদেশ-কেন্দ্রিক ভ্রমণ প্ল্যাটফর্মের ধারণা, যেখানে এজেন্টিক AI ভ্রমণ পরিকল্পনা, বাজেট অপ্টিমাইজেশন, আবাসন ও পরিবহন তথ্য এবং স্থানীয় রাইড ও অভিজ্ঞতার মার্কেটপ্লেস একত্রিত হয়।',
    },
    overview: {
      en: 'Sagar–Pahar AI Travel Agent is a Bangladesh-focused travel concept and prototype designed to unify scattered trip research into one guided workflow. It brings together personalized AI itinerary generation, budget optimization, transport and stay information, and destination-specific local experiences.',
      bn: 'সাগর–পাহাড় AI ট্রাভেল এজেন্ট একটি বাংলাদেশ-কেন্দ্রিক ভ্রমণ কনসেপ্ট ও প্রোটোটাইপ, যা ছড়িয়ে থাকা ভ্রমণ তথ্যকে একটি সুসংগঠিত প্রবাহে আনার জন্য পরিকল্পিত। এতে ব্যক্তিগতকৃত AI ভ্রমণসূচি, বাজেট সমন্বয়, আবাসন ও পরিবহন তথ্য এবং স্থানীয় পর্যটন অভিজ্ঞতা অন্তর্ভুক্ত।',
    },
    problemStatement: {
      en: 'Planning multi-stop trips across Bangladesh often requires juggling disconnected sources for routes, stays, budgets, and local activities—making coherent planning time-consuming.',
      bn: 'বাংলাদেশে ভ্রমণ পরিকল্পনার সময় রুট, আবাসন, বাজেট ও স্থানীয় কার্যক্রমের তথ্য বিভিন্ন বিচ্ছিন্ন উৎস থেকে খুঁজতে হয়, যা সময়সাপেক্ষ ও জটিল।',
    },
    targetUsers: {
      en: 'Students, solo travelers, and small groups planning personalized, budget-conscious journeys to coastal and hill destinations across Bangladesh.',
      bn: 'বাংলাদেশের উপকূলীয় ও পাহাড়ি গন্তব্যে বাজেট-সচেতন এবং ব্যক্তিগতকৃত ভ্রমণের পরিকল্পনা করা শিক্ষার্থী, একক ভ্রমণকারী ও ছোট দল।',
    },
    proposedSolution: {
      en: 'An agentic AI workflow that collects traveler preferences, constraints, and budget targets, then synthesizes a day-by-day itinerary alongside accommodation context, transport options, and local rental or experience listings.',
      bn: 'একটি এজেন্টিক AI ওয়ার্কফ্লো যা ভ্রমণকারীর পছন্দ, সময় ও বাজেট বুঝে দিনভিত্তিক ভ্রমণসূচি, আবাসন ও পরিবহন তথ্য এবং স্থানীয় রাইড বা অভিজ্ঞতার তালিকা সমন্বয় করে।',
    },
    contribution: {
      en: 'Formulated the product concept, destination scope across coastal and hill regions of Bangladesh, and the multi-step agentic planning architecture.',
      bn: 'প্ল্যাটফর্মের মূল ধারণা, বাংলাদেশের উপকূল ও পাহাড়ি গন্তব্যের পরিধি এবং বহু-ধাপের এজেন্টিক পরিকল্পনা কাঠামো প্রণয়ন করা হয়েছে।',
    },
    challengesAndLearning: {
      en: 'Balancing realistic budget constraints, multi-destination travel pacing, and clear boundaries between conceptual AI workflow design and future live booking integrations.',
      bn: 'বাস্তবসম্মত বাজেট সীমাবদ্ধতা, একাধিক গন্তব্যের সময়সূচি এবং কনসেপ্ট পর্যায়ের AI ওয়ার্কফ্লো ও ভবিষ্যৎ লাইভ বুকিং ইন্টিগ্রেশনের সীমারেখা স্পষ্ট রাখা।',
    },
    implementedFeatures: [
      {
        en: 'Product architecture & agentic AI trip-planning workflow concept',
        bn: 'প্রোডাক্ট আর্কিটেকচার ও এজেন্টিক AI ভ্রমণ পরিকল্পনা ওয়ার্কফ্লো কনসেপ্ট',
      },
      {
        en: 'Curated destination scope covering Cox’s Bazar, Saint Martin’s Island, Sajek Valley, and Bandarban',
        bn: 'কক্সবাজার, সেন্ট মার্টিন দ্বীপ, সাজেক ভ্যালি ও বান্দরবান কেন্দ্রিক গন্তব্য পরিধি',
      },
      {
        en: 'Structured separation of itinerary planning, budget optimization, and local experiences',
        bn: 'ভ্রমণসূচি, বাজেট অপ্টিমাইজেশন ও স্থানীয় অভিজ্ঞতার কাঠামোবদ্ধ বিভাজন',
      },
    ],
    plannedFeatures: [
      {
        en: 'AI-powered personalized itinerary generation engine with live budget optimization',
        bn: 'লাইভ বাজেট অপ্টিমাইজেশনসহ AI-চালিত ব্যক্তিগতকৃত ভ্রমণসূচি ইঞ্জিন',
      },
      {
        en: 'Hotel, accommodation, and intercity transport information layer',
        bn: 'হোটেল, আবাসন এবং আন্তঃজেলা পরিবহন তথ্যের সমন্বিত স্তর',
      },
      {
        en: 'Ride rental and local experience marketplace (including cycling where permitted and destination-specific activities)',
        bn: 'রাইড রেন্টাল ও স্থানীয় অভিজ্ঞতার মার্কেটপ্লেস (অনুমোদিত স্থানে সাইক্লিং ও গন্তব্যভিত্তিক কার্যক্রমসহ)',
      },
    ],
    confirmedTechnologies: [],
    stackNote: {
      en: 'Concept & prototype stage — confirmed implementation technologies will be listed once finalized in src/data/projects.ts.',
      bn: 'এটি কনসেপ্ট ও প্রোটোটাইপ পর্যায়ে রয়েছে — চূড়ান্ত হলে নিশ্চিতকৃত প্রযুক্তি স্ট্যাক src/data/projects.ts-এ যুক্ত করা হবে।',
    },
    destinations: [
      "Cox's Bazar",
      "Saint Martin's Island",
      'Sajek Valley',
      'Bandarban',
    ],
    workflowSteps: [
      {
        step: '01',
        title: {
          en: 'Preferences & Budget',
          bn: 'পছন্দ ও বাজেট নির্ধারণ',
        },
        detail: {
          en: 'Traveler specifies destination focus, trip duration, group size, and budget ceiling.',
          bn: 'ভ্রমণকারী গন্তব্য, সময়কাল, ভ্রমণকারীর সংখ্যা এবং বাজেটের সীমা নির্ধারণ করেন।',
        },
      },
      {
        step: '02',
        title: {
          en: 'Agentic Planner',
          bn: 'এজেন্টিক প্ল্যানার',
        },
        detail: {
          en: 'Specialized planning steps balance travel pacing, route order, and budget allocation.',
          bn: 'পরিকল্পনার ধাপগুলো ভ্রমণের গতি, রুটের ক্রম এবং বাজেট বণ্টনের মধ্যে ভারসাম্য রক্ষা করে।',
        },
      },
      {
        step: '03',
        title: {
          en: 'Stay, Transit & Rides',
          bn: 'আবাসন, পরিবহন ও রাইড',
        },
        detail: {
          en: 'Surfaces accommodation context, transport options, and local ride or cycling experiences where permitted.',
          bn: 'আবাসন তথ্য, পরিবহন বিকল্প এবং অনুমোদিত স্থানে স্থানীয় রাইড বা সাইক্লিং অভিজ্ঞতা উপস্থাপন করে।',
        },
      },
      {
        step: '04',
        title: {
          en: 'Actionable Itinerary',
          bn: 'কার্যকর ভ্রমণসূচি',
        },
        detail: {
          en: 'Outputs an organized day-by-day travel plan with transparent cost estimates.',
          bn: 'স্বচ্ছ খরচের ধারণাসহ একটি সুসংগঠিত দিনভিত্তিক ভ্রমণ পরিকল্পনা তৈরি করে।',
        },
      },
    ],
    githubUrl: null,
    liveDemoUrl: null,
    screenshots: [],
  },
];
