import type { EducationEntry, JourneyMilestone } from '../types/portfolio';

/**
 * Verified academic credentials from Mehedi Hasan's CV.
 */
export const educationEntry: EducationEntry = {
  isProvided: true,
  institution: 'Daffodil International University, Dhaka',
  department: 'CGPA: 3.53 / 4.00',
  degree: 'B.Sc. in Software Engineering',
  period: 'Fall 2023 – Present',
  coursework: [
    'Machine Learning',
    'Data Analysis',
    'Statistics',
    'Database Systems',
    'Data Structures',
  ],
  certifications: [],
};

/**
 * Confirmed learning focus tracks aligned with Mehedi's student & aspiring developer profile.
 */
export const learningMilestones: JourneyMilestone[] = [
  {
    id: 'se-foundations',
    title: {
      en: 'Software Engineering Studies',
      bn: 'সফটওয়্যার ইঞ্জিনিয়ারিং অধ্যয়ন',
    },
    category: {
      en: 'Academic Foundation',
      bn: 'একাডেমিক ভিত্তি',
    },
    description: {
      en: 'Building strong fundamentals in structured programming, problem decomposition, and system design as a software engineering student.',
      bn: 'সফটওয়্যার ইঞ্জিনিয়ারিং শিক্ষার্থী হিসেবে স্ট্রাকচার্ড প্রোগ্রামিং, সমস্যা বিশ্লেষণ এবং সিস্টেম ডিজাইনের শক্ত ভিত্তি গড়ে তোলা।',
    },
  },
  {
    id: 'web-product-dev',
    title: {
      en: 'Modern Web Application Development',
      bn: 'আধুনিক ওয়েব অ্যাপ্লিকেশন ডেভেলপমেন্ট',
    },
    category: {
      en: 'Hands-On Engineering',
      bn: 'ব্যবহারিক প্রকৌশল',
    },
    description: {
      en: 'Practicing component architecture, clean responsive interfaces, and full-stack concepts with HTML, JavaScript, React, Next.js, and Node.js.',
      bn: 'HTML, JavaScript, React, Next.js এবং Node.js ব্যবহার করে কম্পোনেন্ট আর্কিটেকচার, পরিচ্ছন্ন রেসপনসিভ ইন্টারফেস ও ফুল-স্ট্যাক ধারণা অনুশীলন।',
    },
  },
  {
    id: 'ai-systems',
    title: {
      en: 'Artificial Intelligence & Agentic Concepts',
      bn: 'কৃত্রিম বুদ্ধিমত্তা ও এজেন্টিক ধারণা',
    },
    category: {
      en: 'Current Focus',
      bn: 'বর্তমান মনোযোগ',
    },
    description: {
      en: 'Exploring how Python, machine learning principles, and multi-step AI workflows can simplify real-world planning and user journeys.',
      bn: 'Python, মেশিন লার্নিংয়ের মূলনীতি এবং বহু-ধাপের AI ওয়ার্কফ্লো কীভাবে বাস্তব জীবনের পরিকল্পনা সহজ করতে পারে তা অন্বেষণ।',
    },
  },
];
