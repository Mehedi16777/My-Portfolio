import { ArrowUp, ExternalLink } from 'lucide-react';
import { siteConfig } from '../../data/site';
import type { TranslationDictionary } from '../../data/translations';
import {
  buildPhoneHref,
  buildWhatsAppHref,
  isValidExternalUrl,
} from '../../utils/portfolio';

interface FooterProps {
  t: TranslationDictionary;
  onNavigateHome: (sectionId?: string) => void;
}

export function Footer({ t, onNavigateHome }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleBackToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-[#30283D] bg-[#09080F]/90">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-md space-y-3">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onNavigateHome();
              }}
              className="inline-block font-display text-lg font-bold tracking-tight text-[#F7F5FA] hover:text-[#A78BFA]"
            >
              {siteConfig.ownerName}
            </a>
            <p className="text-sm leading-relaxed text-[#AAA4B5]">
              {t.footer.statement}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-[#AAA4B5]">
            {(['about', 'skills', 'projects', 'journey', 'contact'] as const).map(
              (section) => (
                <a
                  key={section}
                  href={`/#${section}`}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigateHome(section);
                  }}
                  className="whitespace-nowrap transition-colors duration-150 hover:text-[#F7F5FA]"
                >
                  {t.nav[section]}
                </a>
              ),
            )}
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-[#30283D] pt-8 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-[#AAA4B5]">
            <span>
              © {currentYear} {siteConfig.ownerName}. {t.footer.rights}
            </span>
            <span aria-hidden="true">·</span>
            <a
              href={siteConfig.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[#AAA4B5] transition-colors duration-150 hover:text-[#F7F5FA]"
            >
              GitHub
              <ExternalLink className="h-3 w-3" aria-hidden="true" />
            </a>
            {siteConfig.email && (
              <>
                <span aria-hidden="true">·</span>
                <a
                  href={`mailto:${siteConfig.email}`}
                  className="inline-flex items-center gap-1 text-[#AAA4B5] transition-colors duration-150 hover:text-[#F7F5FA]"
                >
                  {siteConfig.email}
                </a>
              </>
            )}
            {siteConfig.phone && (
              <>
                <span aria-hidden="true">·</span>
                <a
                  href={buildPhoneHref(siteConfig.phone)}
                  className="inline-flex items-center gap-1 font-mono text-[#AAA4B5] tabular-nums transition-colors duration-150 hover:text-[#F7F5FA]"
                >
                  {siteConfig.phone}
                </a>
              </>
            )}
            {siteConfig.whatsappNumber && (
              <>
                <span aria-hidden="true">·</span>
                <a
                  href={buildWhatsAppHref(siteConfig.whatsappNumber)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[#AAA4B5] transition-colors duration-150 hover:text-[#F7F5FA]"
                >
                  {t.contact.whatsappLabel}
                  <ExternalLink className="h-3 w-3" aria-hidden="true" />
                </a>
              </>
            )}
            {isValidExternalUrl(siteConfig.linkedinUrl) && (
              <>
                <span aria-hidden="true">·</span>
                <a
                  href={siteConfig.linkedinUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[#AAA4B5] transition-colors duration-150 hover:text-[#F7F5FA]"
                >
                  LinkedIn
                  <ExternalLink className="h-3 w-3" aria-hidden="true" />
                </a>
              </>
            )}
          </div>

          <button
            type="button"
            onClick={handleBackToTop}
            className="inline-flex min-h-10 items-center gap-2 self-start rounded-lg border border-[#30283D] bg-[#14111D] px-3.5 py-2 text-xs font-medium text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:bg-[#1C1728] sm:self-auto"
          >
            <ArrowUp className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
            {t.footer.backToTop}
          </button>
        </div>
      </div>
    </footer>
  );
}
