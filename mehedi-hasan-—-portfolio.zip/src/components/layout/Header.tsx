import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { siteConfig } from '../../data/site';
import type { Language } from '../../types/portfolio';
import type { TranslationDictionary } from '../../data/translations';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  t: TranslationDictionary;
  activeSection: string;
  isHomeView: boolean;
  onNavigateHome: (sectionId?: string) => void;
}

const NAV_SECTIONS = ['about', 'skills', 'projects', 'journey', 'contact'] as const;

export function Header({
  language,
  onLanguageChange,
  t,
  activeSection,
  isHomeView,
  onNavigateHome,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    sectionId?: string,
  ) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    onNavigateHome(sectionId);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-[#30283D] bg-[#09080F]/95">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-lg focus:bg-[#7547CF] focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-[#F7F5FA]"
      >
        {t.nav.skipToContent}
      </a>

      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single-element brand wordmark */}
        <a
          href="/"
          onClick={(e) => handleNavClick(e)}
          className="font-display text-lg font-bold tracking-tight text-[#F7F5FA] whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-[#A78BFA]"
        >
          {siteConfig.wordmark}
        </a>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7"
        >
          {NAV_SECTIONS.map((sectionId) => {
            const isActive = isHomeView && activeSection === sectionId;
            return (
              <a
                key={sectionId}
                href={`/#${sectionId}`}
                onClick={(e) => handleNavClick(e, sectionId)}
                className={`relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                  isActive
                    ? 'text-[#F7F5FA]'
                    : 'text-[#AAA4B5] hover:text-[#F7F5FA]'
                }`}
              >
                {t.nav[sectionId]}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-0.5 h-0.5 bg-[#7547CF]"
                  />
                )}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Language Switcher (and mobile menu toggle) */}
        <div className="flex items-center gap-3 shrink-0">
          <div
            role="group"
            aria-label="Language switch"
            className="inline-flex items-center rounded-lg border border-[#30283D] bg-[#14111D] p-0.5"
          >
            <button
              type="button"
              onClick={() => onLanguageChange('en')}
              aria-pressed={language === 'en'}
              className={`min-h-8 rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                language === 'en'
                  ? 'bg-[#7547CF] text-[#F7F5FA]'
                  : 'text-[#AAA4B5] hover:text-[#F7F5FA]'
              }`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => onLanguageChange('bn')}
              aria-pressed={language === 'bn'}
              className={`min-h-8 rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                language === 'bn'
                  ? 'bg-[#7547CF] text-[#F7F5FA]'
                  : 'text-[#AAA4B5] hover:text-[#F7F5FA]'
              }`}
            >
              বাংলা
            </button>
          </div>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-nav-drawer"
            aria-label={mobileMenuOpen ? t.nav.menuClose : t.nav.menuOpen}
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-[#30283D] bg-[#14111D] text-[#F7F5FA] transition-colors duration-150 hover:bg-[#1C1728] md:hidden"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileMenuOpen && (
        <nav
          id="mobile-nav-drawer"
          aria-label="Mobile navigation"
          className="border-t border-[#30283D] bg-[#14111D] px-4 py-4 md:hidden"
        >
          <div className="flex flex-col gap-1">
            {NAV_SECTIONS.map((sectionId) => {
              const isActive = isHomeView && activeSection === sectionId;
              return (
                <a
                  key={sectionId}
                  href={`/#${sectionId}`}
                  onClick={(e) => handleNavClick(e, sectionId)}
                  className={`flex min-h-11 items-center rounded-lg px-3 py-2.5 text-sm font-medium transition-colors duration-150 ${
                    isActive
                      ? 'bg-[#1C1728] text-[#F7F5FA]'
                      : 'text-[#AAA4B5] hover:bg-[#1C1728] hover:text-[#F7F5FA]'
                  }`}
                >
                  {t.nav[sectionId]}
                </a>
              );
            })}
          </div>
        </nav>
      )}
    </header>
  );
}
