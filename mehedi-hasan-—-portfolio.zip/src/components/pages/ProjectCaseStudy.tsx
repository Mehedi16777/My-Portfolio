import { ArrowLeft, ExternalLink } from 'lucide-react';
import { ProjectArchitecturalVisual } from '../ui/ProjectArchitecturalVisual';
import type { Language, ProjectData } from '../../types/portfolio';
import type { TranslationDictionary } from '../../data/translations';
import { isValidExternalUrl } from '../../utils/portfolio';

interface ProjectCaseStudyProps {
  project: ProjectData;
  language: Language;
  t: TranslationDictionary;
  onBackHome: () => void;
}

export function ProjectCaseStudy({
  project,
  language,
  t,
  onBackHome,
}: ProjectCaseStudyProps) {
  return (
    <article className="bg-transparent py-12 sm:py-16 lg:py-20">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={onBackHome}
          className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-[#30283D] bg-[#14111D] px-3.5 py-2 text-xs font-medium text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:bg-[#1C1728]"
        >
          <ArrowLeft className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
          {t.caseStudy.backToPortfolio}
        </button>

        <header className="mt-8 space-y-4 border-b border-[#30283D] pb-8">
          <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
            {project.stageLabel[language]}
          </p>
          <h1 className="font-display text-3xl font-bold tracking-tight text-[#F7F5FA] sm:text-4xl [text-wrap:balance]">
            {project.title}
          </h1>
          <p className="text-base font-medium text-[#AAA4B5] sm:text-lg">
            {project.subtitle[language]}
          </p>

          {project.stage === 'concept_prototype' && (
            <p className="rounded-xl border border-[#30283D] bg-[#14111D] px-4 py-3 text-sm leading-relaxed text-[#AAA4B5]">
              {t.caseStudy.prototypeNotice}
            </p>
          )}
        </header>

        <div className="mt-8">
          <ProjectArchitecturalVisual slug={project.slug} />
        </div>

        <div className="mt-10 space-y-10">
          <section className="space-y-3">
            <h2 className="font-display text-xl font-bold text-[#F7F5FA]">
              {t.caseStudy.overview}
            </h2>
            <p className="text-base leading-relaxed text-[#AAA4B5]">
              {project.overview[language]}
            </p>
          </section>

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
              <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
                {t.caseStudy.problem}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-[#AAA4B5]">
                {project.problemStatement[language]}
              </p>
            </section>

            {project.targetUsers && (
              <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
                <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
                  {t.caseStudy.targetUsers}
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-[#AAA4B5]">
                  {project.targetUsers[language]}
                </p>
              </section>
            )}
          </div>

          {project.proposedSolution && (
            <section className="space-y-3">
              <h2 className="font-display text-xl font-bold text-[#F7F5FA]">
                {t.caseStudy.proposedSolution}
              </h2>
              <p className="text-base leading-relaxed text-[#AAA4B5]">
                {project.proposedSolution[language]}
              </p>
            </section>
          )}

          {project.workflowSteps && project.workflowSteps.length > 0 && (
            <section className="space-y-4">
              <h2 className="font-display text-xl font-bold text-[#F7F5FA]">
                {t.caseStudy.agenticWorkflow}
              </h2>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {project.workflowSteps.map((step) => (
                  <div
                    key={step.step}
                    className="rounded-xl border border-[#30283D] bg-[#14111D] p-5"
                  >
                    <p className="font-mono text-xs text-[#A78BFA] tabular-nums">
                      {step.step}
                    </p>
                    <h3 className="mt-2 font-display text-base font-semibold text-[#F7F5FA]">
                      {step.title[language]}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-[#AAA4B5]">
                      {step.detail[language]}
                    </p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {project.destinations && project.destinations.length > 0 && (
            <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
              <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
                {t.caseStudy.destinationsTitle}
              </h2>
              <p className="mt-2 text-sm text-[#AAA4B5]">
                {project.destinations.join(' · ')}
              </p>
            </section>
          )}

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
              <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
                {t.caseStudy.implementedTitle}
              </h2>
              <ul className="mt-3 space-y-2 text-sm leading-relaxed text-[#AAA4B5]">
                {project.implementedFeatures.map((item, idx) => (
                  <li key={idx} className="flex gap-2">
                    <span className="font-mono text-xs text-[#A78BFA] tabular-nums">
                      0{idx + 1}.
                    </span>
                    <span>{item[language]}</span>
                  </li>
                ))}
              </ul>
            </section>

            <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
              <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
                {t.caseStudy.plannedTitle}
              </h2>
              <ul className="mt-3 space-y-2 text-sm leading-relaxed text-[#AAA4B5]">
                {project.plannedFeatures.map((item, idx) => (
                  <li key={idx} className="flex gap-2">
                    <span className="font-mono text-xs text-[#AAA4B5] tabular-nums">
                      0{idx + 1}.
                    </span>
                    <span>{item[language]}</span>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
              <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
                {t.caseStudy.contributionTitle}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-[#AAA4B5]">
                {project.contribution[language]}
              </p>
            </section>

            <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
              <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
                {t.caseStudy.challengesTitle}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-[#AAA4B5]">
                {project.challengesAndLearning[language]}
              </p>
            </section>
          </div>

          <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
            <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
              {t.caseStudy.technologiesTitle}
            </h2>
            {project.confirmedTechnologies.length > 0 ? (
              <p className="mt-2 text-sm text-[#AAA4B5]">
                {project.confirmedTechnologies.join(' · ')}
              </p>
            ) : (
              <p className="mt-2 text-sm text-[#AAA4B5]">
                {project.stackNote[language]}
              </p>
            )}
          </section>

          <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
            <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
              {t.caseStudy.screenshotsTitle}
            </h2>
            {project.screenshots.length > 0 ? (
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                {project.screenshots.map((shot) => (
                  <img
                    key={shot.src}
                    src={shot.src}
                    alt={shot.alt[language]}
                    referrerPolicy="no-referrer"
                    className="rounded-xl border border-[#30283D] object-cover"
                  />
                ))}
              </div>
            ) : (
              <p className="mt-2 text-sm text-[#AAA4B5]">
                {t.caseStudy.screenshotsEmpty}
              </p>
            )}
          </section>

          <section className="rounded-2xl border border-[#30283D] bg-[#14111D] p-6">
            <h2 className="font-display text-base font-semibold text-[#F7F5FA]">
              {t.caseStudy.linksTitle}
            </h2>
            {isValidExternalUrl(project.githubUrl) ||
            isValidExternalUrl(project.liveDemoUrl) ? (
              <div className="mt-4 flex flex-wrap gap-3">
                {isValidExternalUrl(project.githubUrl) && (
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-[#7547CF] px-4 py-2 text-sm font-medium text-[#F7F5FA]"
                  >
                    {t.projects.githubLink}
                    <ExternalLink className="h-4 w-4" aria-hidden="true" />
                  </a>
                )}
                {isValidExternalUrl(project.liveDemoUrl) && (
                  <a
                    href={project.liveDemoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-[#30283D] bg-[#09080F] px-4 py-2 text-sm font-medium text-[#F7F5FA]"
                  >
                    {t.projects.liveDemoLink}
                    <ExternalLink className="h-4 w-4" aria-hidden="true" />
                  </a>
                )}
              </div>
            ) : (
              <p className="mt-2 text-sm text-[#AAA4B5]">
                {t.caseStudy.linksPending}
              </p>
            )}
          </section>
        </div>
      </div>
    </article>
  );
}
