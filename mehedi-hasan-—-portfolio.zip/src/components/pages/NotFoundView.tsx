import { ArrowLeft } from 'lucide-react';
import type { TranslationDictionary } from '../../data/translations';

interface NotFoundViewProps {
  t: TranslationDictionary;
  onBackHome: () => void;
}

export function NotFoundView({ t, onBackHome }: NotFoundViewProps) {
  return (
    <section className="flex min-h-[65vh] items-center justify-center bg-transparent px-4 py-20">
      <div className="max-w-md space-y-5 text-center">
        <p className="font-mono text-sm font-medium text-[#A78BFA]">
          {t.notFound.code}
        </p>
        <h1 className="font-display text-3xl font-bold text-[#F7F5FA]">
          {t.notFound.heading}
        </h1>
        <p className="text-base leading-relaxed text-[#AAA4B5]">
          {t.notFound.body}
        </p>
        <div className="pt-2">
          <button
            type="button"
            onClick={onBackHome}
            className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-[#7547CF] px-5 py-2.5 text-sm font-semibold text-[#F7F5FA] transition-colors duration-150 hover:bg-[#8558dc]"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            {t.notFound.backHome}
          </button>
        </div>
      </div>
    </section>
  );
}
