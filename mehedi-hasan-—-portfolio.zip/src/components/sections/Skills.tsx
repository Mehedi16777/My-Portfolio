import { useState } from 'react';
import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import { skillsData, skillCategoryOrder } from '../../data/skills';
import {
  filterSkills,
  groupSkillsByCategory,
  type SkillFilter,
} from '../../utils/portfolio';
import type { Language } from '../../types/portfolio';
import type { TranslationDictionary } from '../../data/translations';

interface SkillsProps {
  language: Language;
  t: TranslationDictionary;
}

export function Skills({ language, t }: SkillsProps) {
  const [filter, setFilter] = useState<SkillFilter>('all');

  const filtered = filterSkills(skillsData, filter);
  const grouped = groupSkillsByCategory(filtered, skillCategoryOrder);

  const filterOptions: { id: SkillFilter; label: string }[] = [
    { id: 'all', label: t.skills.filterAll },
    { id: 'used', label: t.skills.filterUsed },
    { id: 'learning', label: t.skills.filterLearning },
  ];

  return (
    <section
      id="skills"
      className="border-b border-[#30283D]/80 bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-10">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <SectionHeading
              kicker={t.skills.kicker}
              heading={t.skills.heading}
              lead={t.skills.lead}
            />

            <div
              role="group"
              aria-label={t.skills.heading}
              className="inline-flex flex-wrap items-center gap-1 self-start rounded-lg border border-[#30283D] bg-[#14111D]/95 p-1 md:self-auto"
            >
              {filterOptions.map((option) => {
                const active = filter === option.id;
                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setFilter(option.id)}
                    aria-pressed={active}
                    className={`min-h-9 rounded-md px-3.5 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                      active
                        ? 'bg-[#7547CF] text-[#F7F5FA]'
                        : 'text-[#AAA4B5] hover:text-[#F7F5FA]'
                    }`}
                  >
                    {option.label}
                  </button>
                );
              })}
            </div>
          </div>

          {grouped.length === 0 ? (
            <p className="rounded-xl border border-[#30283D] bg-[#14111D]/90 p-6 text-sm text-[#AAA4B5]">
              {t.skills.emptyFilter}
            </p>
          ) : (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {grouped.map((group) => (
                <TiltCard3D
                  key={group.category}
                  maxTilt={4.5}
                  className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 sm:p-7"
                >
                  <div className="flex items-baseline justify-between border-b border-[#30283D] pb-4">
                    <h3 className="font-display text-lg font-semibold text-[#F7F5FA]">
                      {t.skills.categories[group.category]}
                    </h3>
                    <span className="font-mono text-xs text-[#AAA4B5] tabular-nums">
                      {group.items.length}
                    </span>
                  </div>

                  <ul className="mt-5 divide-y divide-[#30283D]/70">
                    {group.items.map((skill) => (
                      <li
                        key={skill.id}
                        className="py-3.5 first:pt-0 last:pb-0"
                      >
                        <div className="flex flex-wrap items-baseline justify-between gap-2">
                          <span className="font-display text-base font-semibold text-[#F7F5FA]">
                            {skill.name}
                          </span>
                          <span
                            className={`text-xs font-medium ${
                              skill.status === 'used'
                                ? 'text-[#A78BFA]'
                                : 'text-[#AAA4B5]'
                            }`}
                          >
                            {skill.status === 'used'
                              ? t.skills.statusUsed
                              : t.skills.statusLearning}
                          </span>
                        </div>
                        <p className="mt-1 text-sm leading-relaxed text-[#AAA4B5]">
                          {skill.note[language]}
                        </p>
                      </li>
                    ))}
                  </ul>
                </TiltCard3D>
              ))}
            </div>
          )}
        </Reveal>
      </div>
    </section>
  );
}
