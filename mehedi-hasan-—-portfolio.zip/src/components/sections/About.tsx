import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import type { TranslationDictionary } from '../../data/translations';

interface AboutProps {
  t: TranslationDictionary;
}

export function About({ t }: AboutProps) {
  return (
    <section
      id="about"
      className="border-b border-[#30283D]/80 bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-12">
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12">
            <div className="lg:col-span-5">
              <SectionHeading
                kicker={t.about.kicker}
                heading={t.about.heading}
                lead={t.about.lead}
              />
            </div>

            <div className="space-y-5 lg:col-span-7">
              {t.about.paragraphs.map((paragraph, idx) => (
                <p
                  key={idx}
                  className="max-w-[68ch] text-base leading-relaxed text-[#AAA4B5]"
                >
                  {paragraph}
                </p>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 border-t border-[#30283D]/80 pt-10 md:grid-cols-3">
            {t.about.highlights.map((item, idx) => (
              <TiltCard3D
                key={item.title}
                maxTilt={5}
                className="rounded-xl border border-[#30283D] bg-[#14111D]/90 p-6"
              >
                <p
                  style={{ transform: 'translateZ(10px)' }}
                  className="font-mono text-xs text-[#A78BFA] tabular-nums"
                >
                  0{idx + 1}
                </p>
                <h3
                  style={{ transform: 'translateZ(14px)' }}
                  className="mt-3 font-display text-lg font-semibold text-[#F7F5FA]"
                >
                  {item.title}
                </h3>
                <p
                  style={{ transform: 'translateZ(8px)' }}
                  className="mt-2 text-sm leading-relaxed text-[#AAA4B5]"
                >
                  {item.body}
                </p>
              </TiltCard3D>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
