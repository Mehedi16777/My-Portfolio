import { useState } from 'react';
import {
  Check,
  Copy,
  ExternalLink,
  Mail,
  MessageCircle,
  Phone,
  Send,
} from 'lucide-react';
import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import { siteConfig } from '../../data/site';
import type { TranslationDictionary } from '../../data/translations';
import type {
  ContactFormValues,
  ContactValidationErrors,
} from '../../types/portfolio';
import {
  buildMailtoHref,
  buildPhoneHref,
  buildWhatsAppHref,
  formatContactDraft,
  hasValidationErrors,
  isValidExternalUrl,
  validateContactForm,
} from '../../utils/portfolio';

interface ContactProps {
  t: TranslationDictionary;
}

const INITIAL_FORM: ContactFormValues = {
  name: '',
  email: '',
  subject: '',
  message: '',
};

export function Contact({ t }: ContactProps) {
  const [values, setValues] = useState<ContactFormValues>(INITIAL_FORM);
  const [errors, setErrors] = useState<ContactValidationErrors>({});
  const [draftOutput, setDraftOutput] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const hasEndpoint = isValidExternalUrl(siteConfig.contactEndpoint);

  const handleChange = (
    field: keyof ContactFormValues,
    nextValue: string,
  ) => {
    setValues((prev) => ({ ...prev, [field]: nextValue }));
    if (errors[field]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[field];
        return copy;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validation = validateContactForm(values);
    setErrors(validation);

    if (hasValidationErrors(validation)) {
      setDraftOutput(null);
      return;
    }

    // Honest static-site behavior: prepare a validated mailto link & copyable draft instead of faking SMTP delivery
    setDraftOutput(formatContactDraft(values));
    setCopied(false);
  };

  const handleCopyDraft = async () => {
    if (!draftOutput) return;
    try {
      await navigator.clipboard.writeText(draftOutput);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  };

  const mailtoHref =
    siteConfig.email && draftOutput
      ? buildMailtoHref(siteConfig.email, values)
      : null;

  const whatsappDraftHref =
    siteConfig.whatsappNumber && draftOutput
      ? buildWhatsAppHref(siteConfig.whatsappNumber, values)
      : null;

  return (
    <section
      id="contact"
      className="bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-12">
          <SectionHeading
            kicker={t.contact.kicker}
            heading={t.contact.heading}
            lead={t.contact.lead}
          />

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            {/* Direct channels column */}
            <div className="space-y-6 lg:col-span-5">
              <TiltCard3D maxTilt={4} className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 sm:p-7">
                <h3 className="font-display text-lg font-semibold text-[#F7F5FA]">
                  {t.contact.directChannelsTitle}
                </h3>

                <div className="mt-5 space-y-5">
                  <div>
                    <p className="text-xs font-medium text-[#AAA4B5]">
                      {t.contact.emailLabel}
                    </p>
                    {siteConfig.email ? (
                      <a
                        href={`mailto:${siteConfig.email}`}
                        className="mt-1 inline-flex items-center gap-2 text-sm font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                      >
                        <Mail className="h-4 w-4 text-[#A78BFA]" aria-hidden="true" />
                        <span>{siteConfig.email}</span>
                      </a>
                    ) : (
                      <p className="mt-1 text-sm leading-relaxed text-[#AAA4B5]">
                        {t.contact.emailPendingNote}
                      </p>
                    )}
                  </div>

                  {siteConfig.phone && (
                    <div className="border-t border-[#30283D] pt-4">
                      <p className="text-xs font-medium text-[#AAA4B5]">
                        {t.contact.phoneLabel}
                      </p>
                      <a
                        href={buildPhoneHref(siteConfig.phone)}
                        className="mt-1 inline-flex items-center gap-2 font-mono text-sm font-medium text-[#F7F5FA] tabular-nums transition-colors duration-150 hover:text-[#A78BFA]"
                      >
                        <Phone className="h-4 w-4 text-[#A78BFA]" aria-hidden="true" />
                        <span>{siteConfig.phone}</span>
                      </a>
                    </div>
                  )}

                  {siteConfig.whatsappNumber && siteConfig.phone && (
                    <div className="border-t border-[#30283D] pt-4">
                      <p className="text-xs font-medium text-[#AAA4B5]">
                        {t.contact.whatsappLabel}
                      </p>
                      <a
                        href={buildWhatsAppHref(siteConfig.whatsappNumber)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-1 inline-flex items-center gap-2 text-sm font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                      >
                        <MessageCircle className="h-4 w-4 text-[#A78BFA]" aria-hidden="true" />
                        <span className="font-mono tabular-nums">{siteConfig.phone}</span>
                        <span className="text-xs text-[#AAA4B5]">· {t.contact.whatsappChatCta}</span>
                        <ExternalLink className="h-3.5 w-3.5 text-[#AAA4B5]" aria-hidden="true" />
                      </a>
                    </div>
                  )}

                  <div className="border-t border-[#30283D] pt-4">
                    <p className="text-xs font-medium text-[#AAA4B5]">GitHub</p>
                    <a
                      href={siteConfig.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-1 inline-flex items-center gap-1.5 text-sm font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                    >
                      {siteConfig.githubUrl}
                      <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                    </a>
                  </div>

                  {isValidExternalUrl(siteConfig.linkedinUrl) && (
                    <div className="border-t border-[#30283D] pt-4">
                      <p className="text-xs font-medium text-[#AAA4B5]">
                        LinkedIn
                      </p>
                      <a
                        href={siteConfig.linkedinUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-1 inline-flex items-center gap-1.5 text-sm font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                      >
                        {siteConfig.linkedinUrl}
                        <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                      </a>
                    </div>
                  )}
                </div>
              </TiltCard3D>

              {!hasEndpoint && (
                <div className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-5 text-xs leading-relaxed text-[#AAA4B5]">
                  {t.contact.draftModeNotice}
                </div>
              )}
            </div>

            {/* Validated Contact Form */}
            <div className="lg:col-span-7">
              <form
                noValidate
                onSubmit={handleSubmit}
                className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 shadow-[0_18px_40px_-24px_rgba(0,0,0,0.85),inset_0_1px_0_rgba(167,139,250,0.16)] sm:p-7"
              >
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="contact-name"
                      className="block text-xs font-medium text-[#F7F5FA]"
                    >
                      {t.contact.nameLabel}
                    </label>
                    <input
                      id="contact-name"
                      name="name"
                      type="text"
                      value={values.name}
                      onChange={(e) => handleChange('name', e.target.value)}
                      placeholder={t.contact.namePlaceholder}
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? 'contact-name-error' : undefined}
                      className="mt-2 min-h-11 w-full rounded-lg border border-[#30283D] bg-[#09080F] px-3.5 py-2.5 text-sm text-[#F7F5FA] placeholder-[#AAA4B5]/60 transition-colors focus:border-[#A78BFA] focus:outline-none"
                    />
                    {errors.name && (
                      <p
                        id="contact-name-error"
                        role="alert"
                        className="mt-1.5 text-xs text-rose-400"
                      >
                        {t.contact.errors[errors.name]}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="contact-email"
                      className="block text-xs font-medium text-[#F7F5FA]"
                    >
                      {t.contact.emailLabel}
                    </label>
                    <input
                      id="contact-email"
                      name="email"
                      type="email"
                      value={values.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      placeholder={t.contact.emailPlaceholder}
                      aria-invalid={Boolean(errors.email)}
                      aria-describedby={
                        errors.email ? 'contact-email-error' : undefined
                      }
                      className="mt-2 min-h-11 w-full rounded-lg border border-[#30283D] bg-[#09080F] px-3.5 py-2.5 text-sm text-[#F7F5FA] placeholder-[#AAA4B5]/60 transition-colors focus:border-[#A78BFA] focus:outline-none"
                    />
                    {errors.email && (
                      <p
                        id="contact-email-error"
                        role="alert"
                        className="mt-1.5 text-xs text-rose-400"
                      >
                        {t.contact.errors[errors.email]}
                      </p>
                    )}
                  </div>
                </div>

                <div className="mt-5">
                  <label
                    htmlFor="contact-subject"
                    className="block text-xs font-medium text-[#F7F5FA]"
                  >
                    {t.contact.subjectLabel}
                  </label>
                  <input
                    id="contact-subject"
                    name="subject"
                    type="text"
                    value={values.subject}
                    onChange={(e) => handleChange('subject', e.target.value)}
                    placeholder={t.contact.subjectPlaceholder}
                    aria-invalid={Boolean(errors.subject)}
                    aria-describedby={
                      errors.subject ? 'contact-subject-error' : undefined
                    }
                    className="mt-2 min-h-11 w-full rounded-lg border border-[#30283D] bg-[#09080F] px-3.5 py-2.5 text-sm text-[#F7F5FA] placeholder-[#AAA4B5]/60 transition-colors focus:border-[#A78BFA] focus:outline-none"
                  />
                  {errors.subject && (
                    <p
                      id="contact-subject-error"
                      role="alert"
                      className="mt-1.5 text-xs text-rose-400"
                    >
                      {t.contact.errors[errors.subject]}
                    </p>
                  )}
                </div>

                <div className="mt-5">
                  <label
                    htmlFor="contact-message"
                    className="block text-xs font-medium text-[#F7F5FA]"
                  >
                    {t.contact.messageLabel}
                  </label>
                  <textarea
                    id="contact-message"
                    name="message"
                    rows={4}
                    value={values.message}
                    onChange={(e) => handleChange('message', e.target.value)}
                    placeholder={t.contact.messagePlaceholder}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={
                      errors.message ? 'contact-message-error' : undefined
                    }
                    className="mt-2 w-full rounded-lg border border-[#30283D] bg-[#09080F] px-3.5 py-2.5 text-sm text-[#F7F5FA] placeholder-[#AAA4B5]/60 transition-colors focus:border-[#A78BFA] focus:outline-none"
                  />
                  {errors.message && (
                    <p
                      id="contact-message-error"
                      role="alert"
                      className="mt-1.5 text-xs text-rose-400"
                    >
                      {t.contact.errors[errors.message]}
                    </p>
                  )}
                </div>

                <div className="mt-6 flex flex-wrap items-center gap-3">
                  <button
                    type="submit"
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-[#7547CF] px-5 py-2.5 text-sm font-semibold text-[#F7F5FA] whitespace-nowrap shadow-[0_12px_28px_-10px_rgba(117,71,207,0.75)] transition-all duration-150 hover:-translate-y-0.5 hover:bg-[#8558dc]"
                  >
                    {hasEndpoint
                      ? t.contact.submitButton
                      : t.contact.submitButtonDraft}
                  </button>
                </div>

                {draftOutput && (
                  <div
                    role="status"
                    className="mt-6 rounded-xl border border-[#7547CF]/50 bg-[#09080F] p-5"
                  >
                    <h4 className="font-display text-sm font-semibold text-[#F7F5FA]">
                      {t.contact.draftReadyTitle}
                    </h4>
                    <p className="mt-1 text-xs leading-relaxed text-[#AAA4B5]">
                      {siteConfig.email
                        ? t.contact.draftReadyWithEmailBody
                        : t.contact.draftReadyBody}
                    </p>
                    <pre className="mt-3 overflow-x-auto rounded-lg border border-[#30283D] bg-[#14111D] p-3 font-mono text-xs text-[#F7F5FA]">
                      {draftOutput}
                    </pre>
                    <div className="mt-3 flex flex-wrap items-center gap-3">
                      {mailtoHref && (
                        <a
                          href={mailtoHref}
                          className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-[#7547CF] px-4 py-2 text-xs font-semibold text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:bg-[#8558dc]"
                        >
                          <Send className="h-3.5 w-3.5" aria-hidden="true" />
                          {t.contact.openEmailAppButton}
                        </a>
                      )}
                      {whatsappDraftHref && (
                        <a
                          href={whatsappDraftHref}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-[#7547CF]/60 bg-[#1C1728] px-4 py-2 text-xs font-semibold text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:border-[#A78BFA] hover:bg-[#241d34]"
                        >
                          <MessageCircle className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                          {t.contact.openWhatsAppButton}
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={handleCopyDraft}
                        className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-[#30283D] bg-[#14111D] px-3.5 py-2 text-xs font-medium text-[#F7F5FA] transition-colors duration-150 hover:bg-[#1C1728]"
                      >
                        {copied ? (
                          <>
                            <Check className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                            {t.contact.copiedFeedback}
                          </>
                        ) : (
                          <>
                            <Copy className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                            {t.contact.copyDraftButton}
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
