import { useState } from 'react';
import { Download, ExternalLink, Eye, EyeOff, FileText } from 'lucide-react';
import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import { siteConfig } from '../../data/site';
import { skillsData } from '../../data/skills';
import { projectsData } from '../../data/projects';
import type { Language } from '../../types/portfolio';
import type { TranslationDictionary } from '../../data/translations';
import { buildPhoneHref, buildWhatsAppHref } from '../../utils/portfolio';

interface ResumeProps {
  language: Language;
  t: TranslationDictionary;
}

const CV_EDUCATION_ENTRIES = [
  {
    degree: {
      en: 'B.Sc. in Software Engineering',
      bn: 'বি.এসসি. ইন সফটওয়্যার ইঞ্জিনিয়ারিং',
    },
    institution: {
      en: 'Daffodil International University, Dhaka',
      bn: 'ড্যাফোডিল ইন্টারন্যাশনাল ইউনিভার্সিটি, ঢাকা',
    },
    period: 'Fall 2023 – Present',
    grade: 'CGPA: 3.53 / 4.00',
    coursework: [
      'Machine Learning',
      'Data Analysis',
      'Statistics',
      'Database Systems',
      'Data Structures',
    ],
  },
  {
    degree: {
      en: 'Higher Secondary Certificate (HSC)',
      bn: 'উচ্চ মাধ্যমিক সার্টিফিকেট (HSC)',
    },
    institution: {
      en: 'Cantonment College, Jashore',
      bn: 'ক্যান্টনমেন্ট কলেজ, যশোর',
    },
    period: '2021',
    grade: 'GPA: 5.00 / 5.00',
    coursework: [],
  },
  {
    degree: {
      en: 'Secondary School Certificate (SSC)',
      bn: 'মাধ্যমিক স্কুল সার্টিফিকেট (SSC)',
    },
    institution: {
      en: 'Sekenderpur Secondary School',
      bn: 'সেকেন্দারপুর মাধ্যমিক বিদ্যালয়',
    },
    period: '2019',
    grade: 'GPA: 4.63 / 5.00',
    coursework: [],
  },
];

const CV_DATA_PROJECTS = [
  {
    title: 'Breast Cancer Prediction using Machine Learning',
    stack: 'Python · Scikit-learn',
    bullets: {
      en: [
        'Built and compared classification models (Logistic Regression, KNN) to predict diagnosis.',
        'Performed data cleaning, feature analysis, and evaluation using accuracy, precision, and recall.',
      ],
      bn: [
        'রোগ নির্ণয়ের পূর্বাভাসে Logistic Regression ও KNN-সহ শ্রেণিবিন্যাস মডেল তৈরি ও তুলনা করা হয়েছে।',
        'ডেটা ক্লিনিং, ফিচার বিশ্লেষণ এবং accuracy, precision ও recall-এর মাধ্যমে মডেল মূল্যায়ন করা হয়েছে।',
      ],
    },
  },
  {
    title: 'Diabetes Data Analysis',
    stack: 'Python · Pandas · Matplotlib',
    bullets: {
      en: [
        'Explored the dataset, visualized key patterns, and trained predictive models.',
      ],
      bn: [
        'ডেটাসেট বিশ্লেষণ, মূল প্যাটার্ন ভিজ্যুয়ালাইজেশন এবং প্রেডিক্টিভ মডেল প্রশিক্ষণ সম্পন্ন হয়েছে।',
      ],
    },
  },
];

const CV_STACK_GROUPS = [
  {
    label: { en: 'Programming', bn: 'প্রোগ্রামিং' },
    value: 'Python · SQL · R',
  },
  {
    label: { en: 'Data & ML', bn: 'ডেটা ও মেশিন লার্নিং' },
    value: 'Pandas · NumPy · Scikit-learn · Matplotlib · Seaborn',
  },
  {
    label: { en: 'Tools & Databases', bn: 'টুলস ও ডেটাবেস' },
    value: 'Jupyter Notebook · Git/GitHub · Excel · Power BI · MySQL · PostgreSQL',
  },
  {
    label: { en: 'Soft Skills', bn: 'সফট স্কিলস' },
    value: 'Problem-solving · Teamwork · Communication · Time management',
  },
];

export function Resume({ language, t }: ResumeProps) {
  const [showPdfPreview, setShowPdfPreview] = useState(false);

  return (
    <section
      id="resume"
      className="border-b border-[#30283D]/80 bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-10">
          <SectionHeading
            kicker={t.resume.kicker}
            heading={t.resume.heading}
            lead={t.resume.lead}
          />

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            {/* Primary CV PDF Card & Verified Education / ML Projects */}
            <div className="lg:col-span-7">
              <TiltCard3D
                maxTilt={4.5}
                className="flex h-full flex-col justify-between rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 sm:p-7"
              >
                {siteConfig.cvAvailable ? (
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#30283D] pb-5">
                      <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#7547CF]/50 bg-[#09080F]">
                          <FileText
                            className="h-5 w-5 text-[#A78BFA]"
                            aria-hidden="true"
                          />
                        </div>
                        <div>
                          <h3 className="font-display text-lg font-bold text-[#F7F5FA]">
                            {siteConfig.ownerName} — CV (PDF)
                          </h3>
                          <p className="mt-0.5 font-mono text-xs text-[#AAA4B5]">
                            {t.resume.documentMeta}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2.5">
                        <a
                          href={siteConfig.cvFilePath}
                          download="Mehedi_Hasan_CV.pdf"
                          className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-[#7547CF] px-4 py-2 text-sm font-semibold text-[#F7F5FA] whitespace-nowrap shadow-[0_12px_24px_-10px_rgba(117,71,207,0.85)] transition-colors duration-150 hover:bg-[#8558dc]"
                        >
                          <Download className="h-4 w-4" aria-hidden="true" />
                          {t.resume.downloadButton}
                        </a>

                        <a
                          href={siteConfig.cvFilePath}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-[#30283D] bg-[#09080F]/90 px-3.5 py-2 text-sm font-medium text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:bg-[#1C1728]"
                        >
                          <ExternalLink
                            className="h-3.5 w-3.5 text-[#A78BFA]"
                            aria-hidden="true"
                          />
                          {t.resume.openPdfButton}
                        </a>

                        <button
                          type="button"
                          onClick={() => setShowPdfPreview((prev) => !prev)}
                          aria-expanded={showPdfPreview}
                          className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-[#30283D] bg-[#09080F]/90 px-3.5 py-2 text-sm font-medium text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:bg-[#1C1728]"
                        >
                          {showPdfPreview ? (
                            <EyeOff
                              className="h-3.5 w-3.5 text-[#A78BFA]"
                              aria-hidden="true"
                            />
                          ) : (
                            <Eye
                              className="h-3.5 w-3.5 text-[#A78BFA]"
                              aria-hidden="true"
                            />
                          )}
                          {showPdfPreview
                            ? t.resume.hidePreviewButton
                            : t.resume.previewButton}
                        </button>
                      </div>
                    </div>

                    {showPdfPreview && (
                      <div className="overflow-hidden rounded-xl border border-[#30283D] bg-[#09080F]">
                        <object
                          data={`${siteConfig.cvFilePath}#view=FitH`}
                          type="application/pdf"
                          aria-label={`${siteConfig.ownerName} Curriculum Vitae PDF`}
                          className="h-[460px] w-full"
                        >
                          <div className="flex flex-col items-start gap-3 p-5 text-sm text-[#AAA4B5]">
                            <p>{siteConfig.cvUpdatedNote[language]}</p>
                            <a
                              href={siteConfig.cvFilePath}
                              download="Mehedi_Hasan_CV.pdf"
                              className="inline-flex items-center gap-2 font-medium text-[#A78BFA] hover:underline"
                            >
                              <Download className="h-4 w-4" aria-hidden="true" />
                              {t.resume.downloadButton}
                            </a>
                          </div>
                        </object>
                      </div>
                    )}

                    {/* Professional Summary from CV */}
                    <div className="space-y-1.5">
                      <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                        {t.resume.cvSummaryLabel}
                      </p>
                      <p className="text-sm leading-relaxed text-[#AAA4B5]">
                        {t.resume.cvSummaryBody}
                      </p>
                    </div>

                    {/* Education timeline from CV */}
                    <div className="space-y-3 border-t border-[#30283D] pt-5">
                      <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                        {t.resume.educationHeading}
                      </p>
                      <div className="divide-y divide-[#30283D]">
                        {CV_EDUCATION_ENTRIES.map((entry) => (
                          <div
                            key={entry.period}
                            className="py-3 first:pt-0 last:pb-0"
                          >
                            <div className="flex flex-wrap items-baseline justify-between gap-2">
                              <h4 className="font-display text-sm font-semibold text-[#F7F5FA]">
                                {entry.degree[language]}
                              </h4>
                              <span className="font-mono text-xs text-[#AAA4B5] tabular-nums">
                                {entry.period}
                              </span>
                            </div>
                            <div className="mt-1 flex flex-wrap items-center justify-between gap-2 text-xs text-[#AAA4B5]">
                              <span>{entry.institution[language]}</span>
                              <span className="font-mono text-[#A78BFA] tabular-nums">
                                {entry.grade}
                              </span>
                            </div>
                            {entry.coursework.length > 0 && (
                              <p className="mt-2 text-xs leading-relaxed text-[#AAA4B5]">
                                <span className="font-medium text-[#F7F5FA]">
                                  {t.resume.courseworkLabel}:{' '}
                                </span>
                                {entry.coursework.join(' · ')}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Data Science Projects listed in CV */}
                    <div className="space-y-3 border-t border-[#30283D] pt-5">
                      <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                        {t.resume.cvProjectsHeading}
                      </p>
                      <div className="divide-y divide-[#30283D]">
                        {CV_DATA_PROJECTS.map((item) => (
                          <div
                            key={item.title}
                            className="py-3 first:pt-0 last:pb-0"
                          >
                            <div className="flex flex-wrap items-baseline justify-between gap-2">
                              <h4 className="font-display text-sm font-semibold text-[#F7F5FA]">
                                {item.title}
                              </h4>
                              <span className="font-mono text-xs text-[#A78BFA]">
                                {item.stack}
                              </span>
                            </div>
                            <ul className="mt-1.5 space-y-1 text-xs leading-relaxed text-[#AAA4B5]">
                              {item.bullets[language].map((bullet) => (
                                <li key={bullet} className="flex gap-2">
                                  <span
                                    aria-hidden="true"
                                    className="text-[#A78BFA]"
                                  >
                                    —
                                  </span>
                                  <span>{bullet}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2.5">
                      <FileText
                        className="h-5 w-5 text-[#A78BFA]"
                        aria-hidden="true"
                      />
                      <h3 className="font-display text-lg font-semibold text-[#F7F5FA]">
                        {t.resume.pendingTitle}
                      </h3>
                    </div>
                    <p className="text-sm leading-relaxed text-[#AAA4B5]">
                      {t.resume.pendingBody}
                    </p>
                    <p className="rounded-lg border border-[#30283D] bg-[#09080F] px-3.5 py-2.5 font-mono text-xs text-[#AAA4B5]">
                      {siteConfig.cvUpdatedNote[language]}
                    </p>
                  </div>
                )}
              </TiltCard3D>
            </div>

            {/* Right Column: Verified Profile Snapshot & Full CV Technical Stack */}
            <div className="lg:col-span-5">
              <TiltCard3D
                maxTilt={4.5}
                className="flex h-full flex-col justify-between rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 sm:p-7"
              >
                <div>
                  <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                    {t.resume.profileSummaryTitle}
                  </p>
                  <h3 className="mt-3 font-display text-lg font-bold text-[#F7F5FA]">
                    {siteConfig.ownerName}
                  </h3>
                  <p className="mt-1 text-sm text-[#AAA4B5]">
                    {t.resume.summaryRole}
                  </p>

                  <div className="mt-5 space-y-4 border-t border-[#30283D] pt-4 text-sm">
                    {siteConfig.locationConfirmed && (
                      <div>
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.resume.locationLabel}
                        </p>
                        <p className="mt-1 text-[#AAA4B5]">
                          {siteConfig.locationLabel[language]}
                        </p>
                      </div>
                    )}

                    {siteConfig.email && (
                      <div>
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.contact.emailLabel}
                        </p>
                        <a
                          href={`mailto:${siteConfig.email}`}
                          className="mt-1 inline-block text-[#A78BFA] hover:underline"
                        >
                          {siteConfig.email}
                        </a>
                      </div>
                    )}

                    {siteConfig.phone && (
                      <div>
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.contact.phoneLabel} &amp; {t.contact.whatsappLabel}
                        </p>
                        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
                          <a
                            href={buildPhoneHref(siteConfig.phone)}
                            className="font-mono text-[#A78BFA] tabular-nums hover:underline"
                          >
                            {siteConfig.phone}
                          </a>
                          {siteConfig.whatsappNumber && (
                            <>
                              <span aria-hidden="true" className="text-[#30283D]">
                                ·
                              </span>
                              <a
                                href={buildWhatsAppHref(siteConfig.whatsappNumber)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs font-medium text-[#F7F5FA] hover:text-[#A78BFA] hover:underline"
                              >
                                {t.contact.whatsappChatCta}
                              </a>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Technical Stack from CV */}
                    <div className="space-y-3 border-t border-[#30283D] pt-4">
                      <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                        {t.resume.technicalStackHeading}
                      </p>
                      {CV_STACK_GROUPS.map((group) => (
                        <div key={group.label.en}>
                          <p className="text-xs font-medium text-[#F7F5FA]">
                            {group.label[language]}
                          </p>
                          <p className="mt-0.5 text-xs leading-relaxed text-[#AAA4B5]">
                            {group.value}
                          </p>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-3 border-t border-[#30283D] pt-4">
                      <div>
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.resume.extracurricularLabel}
                        </p>
                        <p className="mt-1 text-xs text-[#AAA4B5]">
                          {language === 'en'
                            ? 'Member, Data Science Club'
                            : 'সদস্য, ডেটা সায়েন্স ক্লাব'}
                        </p>
                      </div>

                      <div>
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.resume.languagesLabel}
                        </p>
                        <p className="mt-1 text-xs text-[#AAA4B5]">
                          {language === 'en'
                            ? 'Bangla (Native) · English (Professional Working Proficiency)'
                            : 'বাংলা (মাতৃভাষা) · ইংরেজি (পেশাগত কর্মদক্ষতা)'}
                        </p>
                      </div>

                      <div>
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.resume.summarySkillsLabel}
                        </p>
                        <p className="mt-1 text-xs leading-relaxed text-[#AAA4B5]">
                          {skillsData.map((s) => s.name).join(' · ')}
                        </p>
                      </div>

                      <div>
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.resume.summaryProjectsLabel}
                        </p>
                        <p className="mt-1 text-xs leading-relaxed text-[#AAA4B5]">
                          {projectsData.map((p) => p.title).join(' · ')}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </TiltCard3D>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
