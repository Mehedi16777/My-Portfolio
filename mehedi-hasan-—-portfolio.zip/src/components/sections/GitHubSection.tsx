import { useEffect, useState } from 'react';
import { ExternalLink, GitFork, Star } from 'lucide-react';
import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import { siteConfig } from '../../data/site';
import type { Language } from '../../types/portfolio';
import type { TranslationDictionary } from '../../data/translations';

interface GitHubUser {
  login: string;
  name: string | null;
  bio: string | null;
  public_repos: number;
  followers: number;
  html_url: string;
}

interface GitHubRepo {
  id: number;
  name: string;
  html_url: string;
  description: string | null;
  language: string | null;
  stargazers_count: number;
  forks_count: number;
  updated_at: string;
  fork: boolean;
}

interface GitHubSectionProps {
  language: Language;
  t: TranslationDictionary;
}

export function GitHubSection({ language, t }: GitHubSectionProps) {
  const [user, setUser] = useState<GitHubUser | null>(null);
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'unavailable'>('loading');

  useEffect(() => {
    const controller = new AbortController();

    async function loadGitHub() {
      try {
        const [userRes, reposRes] = await Promise.all([
          fetch(`https://api.github.com/users/${siteConfig.githubUsername}`, {
            signal: controller.signal,
            headers: { Accept: 'application/vnd.github+json' },
          }),
          fetch(
            `https://api.github.com/users/${siteConfig.githubUsername}/repos?sort=updated&per_page=6`,
            {
              signal: controller.signal,
              headers: { Accept: 'application/vnd.github+json' },
            },
          ),
        ]);

        if (!userRes.ok || !reposRes.ok) {
          if (!controller.signal.aborted) {
            setStatus('unavailable');
          }
          return;
        }

        const userData = (await userRes.json()) as GitHubUser;
        const reposData = (await reposRes.json()) as GitHubRepo[];

        if (!controller.signal.aborted) {
          setUser(userData);
          setRepos(Array.isArray(reposData) ? reposData : []);
          setStatus('ready');
        }
      } catch {
        if (!controller.signal.aborted) {
          setStatus('unavailable');
        }
      }
    }

    loadGitHub();
    return () => controller.abort();
  }, []);

  const formatDate = (iso: string) => {
    try {
      return new Intl.DateTimeFormat(language === 'bn' ? 'bn-BD' : 'en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      }).format(new Date(iso));
    } catch {
      return iso.slice(0, 10);
    }
  };

  return (
    <section
      id="github"
      className="border-b border-[#30283D]/80 bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-10">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <SectionHeading
              kicker={t.github.kicker}
              heading={t.github.heading}
              lead={t.github.lead}
            />

            <a
              href={siteConfig.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-11 items-center gap-2 self-start rounded-lg border border-[#30283D] bg-[#14111D]/95 px-4 py-2.5 text-sm font-medium text-[#F7F5FA] whitespace-nowrap transition-all duration-150 hover:-translate-y-0.5 hover:border-[#A78BFA] hover:bg-[#1C1728] md:self-auto"
            >
              {t.github.visitProfile}
              <ExternalLink className="h-4 w-4 text-[#A78BFA]" aria-hidden="true" />
            </a>
          </div>

          {status === 'loading' && (
            <div
              role="status"
              className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 text-sm text-[#AAA4B5]"
            >
              {t.github.loadingRepos}
            </div>
          )}

          {status === 'unavailable' && (
            <div className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 sm:p-7">
              <h3 className="font-display text-base font-semibold text-[#F7F5FA]">
                {t.github.apiFallbackTitle}
              </h3>
              <p className="mt-2 max-w-[65ch] text-sm leading-relaxed text-[#AAA4B5]">
                {t.github.apiFallbackBody}
              </p>
              <a
                href={siteConfig.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-[#A78BFA] hover:underline"
              >
                {siteConfig.githubUrl}
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            </div>
          )}

          {status === 'ready' && user && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[#30283D] bg-[#14111D]/90 px-6 py-5 shadow-[0_18px_40px_-24px_rgba(0,0,0,0.85),inset_0_1px_0_rgba(167,139,250,0.16)]">
                <div className="space-y-1">
                  <p className="font-display text-lg font-bold text-[#F7F5FA]">
                    {user.name || user.login}
                  </p>
                  <p className="font-mono text-xs text-[#A78BFA]">
                    @{user.login}
                  </p>
                  {user.bio && (
                    <p className="pt-1 text-sm text-[#AAA4B5]">{user.bio}</p>
                  )}
                </div>

                <div className="flex items-center gap-6 text-sm">
                  <div>
                    <p className="text-xs text-[#AAA4B5]">
                      {t.github.publicReposLabel}
                    </p>
                    <p className="font-mono text-base font-semibold text-[#F7F5FA] tabular-nums">
                      {user.public_repos}
                    </p>
                  </div>
                  <div className="border-l border-[#30283D] pl-6">
                    <p className="text-xs text-[#AAA4B5]">
                      {t.github.followersLabel}
                    </p>
                    <p className="font-mono text-base font-semibold text-[#F7F5FA] tabular-nums">
                      {user.followers}
                    </p>
                  </div>
                </div>
              </div>

              {repos.length > 0 && (
                <div className="space-y-4">
                  <h3 className="font-display text-base font-semibold text-[#F7F5FA]">
                    {t.github.reposHeading}
                  </h3>
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {repos.map((repo) => (
                      <TiltCard3D
                        key={repo.id}
                        maxTilt={5}
                        className="rounded-xl border border-[#30283D] bg-[#14111D]/90 transition-colors duration-150 hover:bg-[#1C1728]/95"
                      >
                        <a
                          href={repo.html_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex h-full flex-col justify-between p-5"
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2">
                              <span className="font-display text-base font-semibold text-[#F7F5FA]">
                                {repo.name}
                              </span>
                              <ExternalLink
                                className="h-3.5 w-3.5 shrink-0 text-[#AAA4B5]"
                                aria-hidden="true"
                              />
                            </div>
                            <p className="mt-2 text-sm leading-relaxed text-[#AAA4B5]">
                              {repo.description || t.github.noDescription}
                            </p>
                          </div>

                          <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-[#30283D] pt-3 text-xs text-[#AAA4B5]">
                            {repo.language && (
                              <span className="text-[#A78BFA]">{repo.language}</span>
                            )}
                            <span className="inline-flex items-center gap-1 tabular-nums">
                              <Star className="h-3 w-3" aria-hidden="true" />
                              {repo.stargazers_count}
                            </span>
                            <span className="inline-flex items-center gap-1 tabular-nums">
                              <GitFork className="h-3 w-3" aria-hidden="true" />
                              {repo.forks_count}
                            </span>
                            <span className="ml-auto font-mono text-[11px] tabular-nums">
                              {t.github.updatedLabel}: {formatDate(repo.updated_at)}
                            </span>
                          </div>
                        </a>
                      </TiltCard3D>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </Reveal>
      </div>
    </section>
  );
}
