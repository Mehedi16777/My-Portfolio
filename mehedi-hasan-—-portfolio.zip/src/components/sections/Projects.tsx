import { ArrowUpRight, ExternalLink } from 'lucide-react';
import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import { ProjectArchitecturalVisual } from '../ui/ProjectArchitecturalVisual';
import { projectsData } from '../../data/projects';
import type { Language, ProjectSlug } from '../../types/portfolio';
import type { TranslationDictionary } from '../../data/translations';
import { isValidExternalUrl } from '../../utils/portfolio';

interface ProjectsProps {
  language: Language;
  t: TranslationDictionary;
  onOpenProject: (slug: ProjectSlug) => void;
}

export function Projects({ language, t, onOpenProject }: ProjectsProps) {
  return (
    <section
      id="projects"
      className="border-b border-[#30283D]/80 bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-12">
          <SectionHeading
            kicker={t.projects.kicker}
            heading={t.projects.heading}
            lead={t.projects.lead}
          />

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
            {projectsData.map((project, index) => (
              <TiltCard3D
                key={project.slug}
                maxTilt={4.5}
                className="flex flex-col justify-between rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 transition-colors duration-200 hover:bg-[#1C1728]/95 sm:p-7"
              >
                <article className="flex h-full flex-col justify-between">
                  <div className="space-y-6">
                    <div style={{ transform: 'translateZ(18px)' }}>
                      <ProjectArchitecturalVisual slug={project.slug} />
                    </div>

                    <div
                      style={{ transform: 'translateZ(12px)' }}
                      className="space-y-3"
                    >
                      <div className="flex flex-wrap items-center gap-2 text-xs text-[#A78BFA]">
                        <span className="font-mono tabular-nums">
                          0{index + 1}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-medium">
                          {project.stageLabel[language]}
                        </span>
                      </div>

                      <h3 className="font-display text-xl font-bold text-[#F7F5FA] sm:text-2xl">
                        {project.title}
                      </h3>

                      <p className="text-sm font-medium text-[#AAA4B5]">
                        {project.subtitle[language]}
                      </p>

                      <p className="text-sm leading-relaxed text-[#AAA4B5] sm:text-base">
                        {project.shortDescription[language]}
                      </p>

                      {project.destinations && project.destinations.length > 0 && (
                        <p className="text-xs leading-relaxed text-[#AAA4B5]">
                          <span className="font-medium text-[#F7F5FA]">
                            {t.projects.destinationsLabel}:{' '}
                          </span>
                          {project.destinations.join(' · ')}
                        </p>
                      )}

                      <div className="border-t border-[#30283D] pt-3 text-xs text-[#AAA4B5]">
                        {project.confirmedTechnologies.length > 0 ? (
                          <span>{project.confirmedTechnologies.join(' · ')}</span>
                        ) : (
                          <span>{t.projects.stackPending}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div
                    style={{ transform: 'translateZ(16px)' }}
                    className="mt-6 flex flex-wrap items-center gap-3 pt-2"
                  >
                    <button
                      type="button"
                      onClick={() => onOpenProject(project.slug)}
                      aria-label={`${t.projects.viewCaseStudy}: ${project.title}`}
                      className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-[#7547CF] px-4 py-2 text-sm font-semibold text-[#F7F5FA] whitespace-nowrap shadow-[0_10px_24px_-10px_rgba(117,71,207,0.8)] transition-colors duration-150 hover:bg-[#8558dc]"
                    >
                      {t.projects.viewCaseStudy}
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    </button>

                    {isValidExternalUrl(project.githubUrl) && (
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-[#30283D] bg-[#09080F] px-3.5 py-2 text-xs font-medium text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:border-[#A78BFA]"
                      >
                        {t.projects.githubLink}
                        <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                      </a>
                    )}

                    {isValidExternalUrl(project.liveDemoUrl) && (
                      <a
                        href={project.liveDemoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-[#30283D] bg-[#09080F] px-3.5 py-2 text-xs font-medium text-[#F7F5FA] whitespace-nowrap transition-colors duration-150 hover:border-[#A78BFA]"
                      >
                        {t.projects.liveDemoLink}
                        <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                </article>
              </TiltCard3D>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
