import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import { educationEntry, learningMilestones } from '../../data/journey';
import type { Language } from '../../types/portfolio';
import type { TranslationDictionary } from '../../data/translations';

interface JourneyProps {
  language: Language;
  t: TranslationDictionary;
}

export function Journey({ language, t }: JourneyProps) {
  return (
    <section
      id="journey"
      className="border-b border-[#30283D]/80 bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-12">
          <SectionHeading
            kicker={t.journey.kicker}
            heading={t.journey.heading}
            lead={t.journey.lead}
          />

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            {/* Academic credentials column — never fabricates unprovided data */}
            <div className="lg:col-span-5">
              <TiltCard3D
                maxTilt={4.5}
                className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 sm:p-7"
              >
                <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                  {t.journey.academicLabel}
                </p>

                {educationEntry.isProvided ? (
                  <div className="mt-4 space-y-4">
                    <div>
                      <h3 className="font-display text-lg font-bold text-[#F7F5FA]">
                        {educationEntry.degree}
                      </h3>
                      <p className="mt-1 text-sm font-medium text-[#AAA4B5]">
                        {[educationEntry.institution, educationEntry.department]
                          .filter(Boolean)
                          .join(' · ')}
                      </p>
                      {educationEntry.period && (
                        <p className="mt-1 font-mono text-xs text-[#AAA4B5] tabular-nums">
                          {educationEntry.period}
                        </p>
                      )}
                    </div>

                    {educationEntry.coursework.length > 0 && (
                      <div className="border-t border-[#30283D] pt-4">
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.journey.courseworkLabel}
                        </p>
                        <p className="mt-1.5 text-sm leading-relaxed text-[#AAA4B5]">
                          {educationEntry.coursework.join(' · ')}
                        </p>
                      </div>
                    )}

                    {educationEntry.certifications.length > 0 && (
                      <div className="border-t border-[#30283D] pt-4">
                        <p className="text-xs font-medium text-[#F7F5FA]">
                          {t.journey.certificationsLabel}
                        </p>
                        <ul className="mt-1.5 space-y-1 text-sm text-[#AAA4B5]">
                          {educationEntry.certifications.map((cert) => (
                            <li key={cert}>{cert}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="mt-4 space-y-3">
                    <h3 className="font-display text-lg font-semibold text-[#F7F5FA]">
                      {t.journey.academicPendingTitle}
                    </h3>
                    <p className="text-sm leading-relaxed text-[#AAA4B5]">
                      {t.journey.academicPendingBody}
                    </p>
                  </div>
                )}
              </TiltCard3D>
            </div>

            {/* Learning tracks column */}
            <div className="lg:col-span-7">
              <TiltCard3D
                maxTilt={4}
                className="rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-6 sm:p-7"
              >
                <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                  {t.journey.tracksHeading}
                </p>

                <ol className="mt-5 divide-y divide-[#30283D]">
                  {learningMilestones.map((milestone, idx) => (
                    <li
                      key={milestone.id}
                      className="py-5 first:pt-0 last:pb-0"
                    >
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <h3 className="font-display text-base font-semibold text-[#F7F5FA]">
                          <span className="mr-1.5 font-mono text-xs text-[#A78BFA] tabular-nums">
                            0{idx + 1}.
                          </span>{' '}
                          {milestone.title[language]}
                        </h3>
                        <span className="text-xs text-[#AAA4B5]">
                          {milestone.category[language]}
                        </span>
                      </div>
                      <p className="mt-2 text-sm leading-relaxed text-[#AAA4B5]">
                        {milestone.description[language]}
                      </p>
                    </li>
                  ))}
                </ol>
              </TiltCard3D>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
