import { Reveal } from '../ui/Reveal';
import { SectionHeading } from '../ui/SectionHeading';
import { TiltCard3D } from '../ui/TiltCard3D';
import type { TranslationDictionary } from '../../data/translations';

interface InterestsProps {
  t: TranslationDictionary;
}

export function Interests({ t }: InterestsProps) {
  return (
    <section
      id="interests"
      className="border-b border-[#30283D]/80 bg-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="space-y-10">
          <SectionHeading
            kicker={t.interests.kicker}
            heading={t.interests.heading}
            lead={t.interests.lead}
          />

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {t.interests.items.map((item, idx) => (
              <TiltCard3D
                key={item.title}
                maxTilt={6}
                className="flex flex-col justify-between rounded-2xl border border-[#30283D] bg-[#14111D]/90 p-5 transition-colors duration-150 hover:bg-[#1C1728]/95"
              >
                <div>
                  <span className="font-mono text-xs text-[#A78BFA] tabular-nums">
                    0{idx + 1}
                  </span>
                  <h3 className="mt-3 font-display text-base font-semibold text-[#F7F5FA]">
                    {item.title}
                  </h3>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-[#AAA4B5]">
                  {item.description}
                </p>
              </TiltCard3D>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
