import { useState } from 'react';
import {
  ArrowDownRight,
  Download,
  ExternalLink,
  FileText,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
} from 'lucide-react';
import { TiltCard3D } from '../ui/TiltCard3D';
import { siteConfig } from '../../data/site';
import type { TranslationDictionary } from '../../data/translations';
import type { Language } from '../../types/portfolio';
import {
  buildPhoneHref,
  buildWhatsAppHref,
  isValidExternalUrl,
} from '../../utils/portfolio';

interface HeroProps {
  language: Language;
  t: TranslationDictionary;
  onScrollToSection: (sectionId: string) => void;
}

export function Hero({ language, t, onScrollToSection }: HeroProps) {
  const [imageError, setImageError] = useState(false);

  return (
    <section
      id="home"
      className="relative border-b border-[#30283D]/80 bg-transparent pt-12 pb-16 sm:pt-16 sm:pb-20 lg:pt-20 lg:pb-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left column: primary editorial introduction */}
          <div className="flex flex-col justify-between lg:col-span-7">
            <div className="space-y-6">
              <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
                {t.hero.eyebrow}
              </p>

              <h1 className="font-display text-[clamp(2.25rem,4.1vw,3.6rem)] font-bold leading-[1.12] tracking-tight text-[#F7F5FA] [text-wrap:balance]">
                {t.hero.headline}
              </h1>

              <p className="text-sm font-medium text-[#A78BFA] sm:text-base">
                {t.hero.subtitle}
              </p>

              <p className="max-w-[65ch] text-base leading-relaxed text-[#AAA4B5] sm:text-lg">
                {t.hero.introduction}
              </p>
            </div>

            <div className="mt-8 space-y-6">
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onScrollToSection('projects')}
                  className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-[#7547CF] px-5 py-2.5 text-sm font-semibold text-[#F7F5FA] whitespace-nowrap shadow-[0_14px_30px_-10px_rgba(117,71,207,0.85)] transition-all duration-150 hover:-translate-y-0.5 hover:bg-[#8558dc]"
                >
                  {t.hero.primaryCta}
                  <ArrowDownRight className="h-4 w-4" aria-hidden="true" />
                </button>

                {siteConfig.cvAvailable ? (
                  <a
                    href={siteConfig.cvFilePath}
                    download="Mehedi_Hasan_CV.pdf"
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-[#30283D] bg-[#14111D]/90 px-5 py-2.5 text-sm font-medium text-[#F7F5FA] whitespace-nowrap transition-all duration-150 hover:-translate-y-0.5 hover:bg-[#1C1728]"
                  >
                    <Download className="h-4 w-4 text-[#A78BFA]" aria-hidden="true" />
                    {t.hero.secondaryCtaReady}
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={() => onScrollToSection('resume')}
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-[#30283D] bg-[#14111D]/90 px-5 py-2.5 text-sm font-medium text-[#F7F5FA] whitespace-nowrap transition-all duration-150 hover:-translate-y-0.5 hover:bg-[#1C1728]"
                  >
                    <FileText className="h-4 w-4 text-[#A78BFA]" aria-hidden="true" />
                    {t.hero.secondaryCtaFallback}
                  </button>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-[#AAA4B5]">
                <a
                  href={siteConfig.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                >
                  <span>{t.hero.githubLabel}</span>
                  <span className="text-[#AAA4B5]">@{siteConfig.githubUsername}</span>
                  <ExternalLink className="h-3.5 w-3.5 text-[#AAA4B5]" aria-hidden="true" />
                </a>

                {siteConfig.email && (
                  <>
                    <span aria-hidden="true" className="text-[#30283D]">
                      /
                    </span>
                    <a
                      href={`mailto:${siteConfig.email}`}
                      className="inline-flex items-center gap-1.5 font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                    >
                      <Mail className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                      <span>{siteConfig.email}</span>
                    </a>
                  </>
                )}

                {siteConfig.phone && (
                  <>
                    <span aria-hidden="true" className="text-[#30283D]">
                      /
                    </span>
                    <a
                      href={buildPhoneHref(siteConfig.phone)}
                      className="inline-flex items-center gap-1.5 font-mono text-xs font-medium text-[#F7F5FA] tabular-nums transition-colors duration-150 hover:text-[#A78BFA] sm:text-sm"
                    >
                      <Phone className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                      <span>{siteConfig.phone}</span>
                    </a>
                  </>
                )}

                {siteConfig.whatsappNumber && (
                  <>
                    <span aria-hidden="true" className="text-[#30283D]">
                      /
                    </span>
                    <a
                      href={buildWhatsAppHref(siteConfig.whatsappNumber)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                    >
                      <MessageCircle className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                      <span>{t.contact.whatsappLabel}</span>
                      <ExternalLink className="h-3 w-3 text-[#AAA4B5]" aria-hidden="true" />
                    </a>
                  </>
                )}

                {isValidExternalUrl(siteConfig.linkedinUrl) && (
                  <>
                    <span aria-hidden="true" className="text-[#30283D]">
                      /
                    </span>
                    <a
                      href={siteConfig.linkedinUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 font-medium text-[#F7F5FA] transition-colors duration-150 hover:text-[#A78BFA]"
                    >
                      <span>{t.hero.linkedinLabel}</span>
                      <ExternalLink className="h-3.5 w-3.5 text-[#AAA4B5]" aria-hidden="true" />
                    </a>
                  </>
                )}

                {siteConfig.locationConfirmed && (
                  <>
                    <span aria-hidden="true" className="text-[#30283D]">
                      ·
                    </span>
                    <span className="inline-flex items-center gap-1.5 text-[#AAA4B5]">
                      <MapPin className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                      {siteConfig.locationLabel[language]}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Right column: Multi-Layer 3D Obsidian-Violet Portrait Stage */}
          <div className="flex lg:col-span-5">
            <TiltCard3D
              maxTilt={8}
              className="w-full rounded-2xl border border-[#7547CF]/50 bg-[#0E0B18]/20 p-4 shadow-[0_32px_70px_-24px_rgba(9,8,15,0.96),0_0_60px_-14px_rgba(117,71,207,0.5)] sm:p-5"
            >
              <div className="relative flex h-full flex-col justify-between gap-4">
                {/* Layer 1 (Back Z plane): Volumetric purple studio aura & 3D depth rings */}
                <div
                  aria-hidden="true"
                  style={{ transform: 'translateZ(-14px)' }}
                  className="pointer-events-none absolute inset-3 overflow-hidden rounded-xl"
                >
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(167,139,250,0.34),rgba(117,71,207,0.16)_46%,transparent_74%)]" />
                  <svg
                    viewBox="0 0 400 400"
                    className="h-full w-full opacity-55"
                    fill="none"
                  >
                    <ellipse
                      cx="200"
                      cy="210"
                      rx="168"
                      ry="68"
                      transform="rotate(-18 200 210)"
                      stroke="#A78BFA"
                      strokeOpacity="0.45"
                      strokeWidth="1.2"
                      strokeDasharray="6 6"
                    />
                    <ellipse
                      cx="200"
                      cy="210"
                      rx="154"
                      ry="58"
                      transform="rotate(22 200 210)"
                      stroke="#7547CF"
                      strokeOpacity="0.6"
                      strokeWidth="1.4"
                    />
                    <circle
                      cx="200"
                      cy="176"
                      r="128"
                      stroke="#30283D"
                      strokeWidth="1"
                    />
                  </svg>
                </div>

                {/* Layer 2 (Mid Z plane): Feather-masked studio portrait harmonized into 3D violet light */}
                <div
                  style={{ transform: 'translateZ(26px)' }}
                  className="relative overflow-hidden rounded-xl"
                >
                  {siteConfig.profileImagePath && !imageError ? (
                    <div className="relative aspect-square w-full">
                      <img
                        src={siteConfig.profileImagePath}
                        alt={siteConfig.ownerName}
                        referrerPolicy="no-referrer"
                        onError={() => setImageError(true)}
                        style={{
                          maskImage:
                            'radial-gradient(ellipse 70% 78% at 50% 44%, #000 36%, rgba(0,0,0,0.48) 60%, transparent 88%)',
                          WebkitMaskImage:
                            'radial-gradient(ellipse 70% 78% at 50% 44%, #000 36%, rgba(0,0,0,0.48) 60%, transparent 88%)',
                        }}
                        className="h-full w-full scale-[1.04] object-cover object-top contrast-[1.12] saturate-[0.9] brightness-[0.96]"
                      />
                      {/* Deep obsidian-violet perimeter vignette melts studio halo into 3D space */}
                      <div
                        aria-hidden="true"
                        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,transparent_30%,rgba(28,17,56,0.55)_58%,rgba(9,8,15,0.94)_88%)]"
                      />
                      {/* Directional purple studio rim-light harmony overlay */}
                      <div
                        aria-hidden="true"
                        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_16%_18%,rgba(167,139,250,0.28),transparent_44%),radial-gradient(circle_at_84%_72%,rgba(117,71,207,0.34),transparent_50%)] mix-blend-screen"
                      />
                      <div
                        aria-hidden="true"
                        className="pointer-events-none absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-[#09080F] via-[#09080F]/65 to-transparent"
                      />
                    </div>
                  ) : (
                    <div className="flex aspect-square w-full items-center justify-center rounded-xl bg-[#14111D]/80 p-6 text-center">
                      <span className="font-display text-2xl font-bold text-[#F7F5FA]">
                        {siteConfig.ownerName}
                      </span>
                    </div>
                  )}

                  {/* Chamfered 3D viewfinder framing corners */}
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute top-2.5 left-2.5 h-5 w-5 border-t-2 border-l-2 border-[#A78BFA]/70 rounded-tl-md"
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute top-2.5 right-2.5 h-5 w-5 border-t-2 border-r-2 border-[#A78BFA]/70 rounded-tr-md"
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute bottom-2.5 left-2.5 h-5 w-5 border-b-2 border-l-2 border-[#7547CF]/70 rounded-bl-md"
                  />
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute bottom-2.5 right-2.5 h-5 w-5 border-b-2 border-r-2 border-[#7547CF]/70 rounded-br-md"
                  />
                </div>

                {/* Layer 3 (Foreground Z plane): Elevated 3D nameplate */}
                <div
                  style={{ transform: 'translateZ(42px)' }}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#30283D]/90 bg-[#09080F]/85 px-4 py-3 text-xs shadow-[0_12px_28px_-14px_rgba(0,0,0,0.9)]"
                >
                  <div>
                    <p className="font-display text-sm font-semibold text-[#F7F5FA]">
                      {siteConfig.ownerName}
                    </p>
                    <p className="text-[#AAA4B5]">
                      {language === 'en'
                        ? 'Student & Aspiring Developer'
                        : 'শিক্ষার্থী ও উদীয়মান ডেভেলপার'}
                    </p>
                  </div>
                  <span className="font-mono text-[#A78BFA]">
                    @{siteConfig.githubUsername}
                  </span>
                </div>
              </div>
            </TiltCard3D>
          </div>
        </div>

        {/* Full-width summary strip below hero split */}
        <div className="mt-12 grid grid-cols-1 gap-6 border-t border-[#30283D]/80 pt-8 sm:grid-cols-3">
          {t.hero.focusItems.map((item) => (
            <div key={item.label} className="space-y-1">
              <p className="text-xs font-medium text-[#AAA4B5]">{item.label}</p>
              <p className="font-display text-base font-semibold text-[#F7F5FA]">
                {item.value}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
