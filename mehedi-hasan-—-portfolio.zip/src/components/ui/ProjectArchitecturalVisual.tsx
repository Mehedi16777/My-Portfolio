import type { ProjectSlug } from '../../types/portfolio';

interface ProjectArchitecturalVisualProps {
  slug: ProjectSlug;
}

/**
 * Clean 3D-tilted architectural schematics for featured projects.
 * Provides authentic visual structure without inventing unverified screenshots.
 */
export function ProjectArchitecturalVisual({
  slug,
}: ProjectArchitecturalVisualProps) {
  if (slug === 'bus-ticket-reservation') {
    return (
      <div
        aria-hidden="true"
        style={{ perspective: '760px' }}
        className="relative flex h-44 w-full items-center justify-center overflow-hidden rounded-xl border border-[#30283D] bg-[radial-gradient(circle_at_50%_0%,rgba(117,71,207,0.22),#09080F_72%)] p-5 shadow-[inset_0_1px_0_rgba(167,139,250,0.2)]"
      >
        <div
          style={{
            transform: 'rotateX(12deg) translateZ(10px)',
            transformStyle: 'preserve-3d',
          }}
          className="w-full max-w-[340px]"
        >
          <svg
            viewBox="0 0 360 140"
            className="h-full w-full drop-shadow-[0_14px_22px_rgba(0,0,0,0.72)]"
            fill="none"
          >
            {/* Route nodes */}
            <rect
              x="16"
              y="24"
              width="92"
              height="40"
              rx="8"
              fill="#14111D"
              stroke="#30283D"
            />
            <text
              x="62"
              y="48"
              textAnchor="middle"
              fill="#F7F5FA"
              fontSize="11"
              fontFamily="JetBrains Mono, monospace"
            >
              Route Select
            </text>

            <path
              d="M108 44 H134"
              stroke="#7547CF"
              strokeWidth="1.5"
              strokeDasharray="3 3"
            />

            <rect
              x="134"
              y="24"
              width="92"
              height="40"
              rx="8"
              fill="#1C1728"
              stroke="#A78BFA"
            />
            <text
              x="180"
              y="48"
              textAnchor="middle"
              fill="#A78BFA"
              fontSize="11"
              fontFamily="JetBrains Mono, monospace"
            >
              Seat Matrix
            </text>

            <path
              d="M226 44 H252"
              stroke="#7547CF"
              strokeWidth="1.5"
              strokeDasharray="3 3"
            />

            <rect
              x="252"
              y="24"
              width="92"
              height="40"
              rx="8"
              fill="#14111D"
              stroke="#30283D"
            />
            <text
              x="298"
              y="48"
              textAnchor="middle"
              fill="#F7F5FA"
              fontSize="11"
              fontFamily="JetBrains Mono, monospace"
            >
              Booking Log
            </text>

            {/* Seat grid schematic below */}
            {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => {
              const x = 68 + i * 28;
              const selected = i === 2 || i === 5;
              return (
                <rect
                  key={i}
                  x={x}
                  y="88"
                  width="20"
                  height="20"
                  rx="4"
                  fill={selected ? '#7547CF' : '#14111D'}
                  stroke={selected ? '#A78BFA' : '#30283D'}
                />
              );
            })}
          </svg>
        </div>
      </div>
    );
  }

  return (
    <div
      aria-hidden="true"
      style={{ perspective: '760px' }}
      className="relative flex h-44 w-full items-center justify-center overflow-hidden rounded-xl border border-[#30283D] bg-[radial-gradient(circle_at_50%_0%,rgba(117,71,207,0.22),#09080F_72%)] p-5 shadow-[inset_0_1px_0_rgba(167,139,250,0.2)]"
    >
      <div
        style={{
          transform: 'rotateX(12deg) translateZ(10px)',
          transformStyle: 'preserve-3d',
        }}
        className="w-full max-w-[340px]"
      >
        <svg
          viewBox="0 0 360 140"
          className="h-full w-full drop-shadow-[0_14px_22px_rgba(0,0,0,0.72)]"
          fill="none"
        >
          {/* Topographical wave & mountain contour lines representing Sagar (sea) & Pahar (hills) */}
          <path
            d="M16 118 Q65 98 115 114 T215 110 T344 116"
            stroke="#30283D"
            strokeWidth="1.2"
          />
          <path
            d="M200 108 L244 64 L276 92 L308 54 L344 108"
            stroke="#7547CF"
            strokeOpacity="0.55"
            strokeWidth="1.5"
          />

          {/* Agentic planner nodes */}
          <rect
            x="16"
            y="20"
            width="96"
            height="36"
            rx="8"
            fill="#14111D"
            stroke="#30283D"
          />
          <text
            x="64"
            y="42"
            textAnchor="middle"
            fill="#AAA4B5"
            fontSize="10"
            fontFamily="JetBrains Mono, monospace"
          >
            Budget &amp; Goals
          </text>

          <path d="M112 38 H132" stroke="#7547CF" strokeWidth="1.5" />

          <rect
            x="132"
            y="16"
            width="98"
            height="44"
            rx="8"
            fill="#1C1728"
            stroke="#A78BFA"
          />
          <text
            x="181"
            y="42"
            textAnchor="middle"
            fill="#A78BFA"
            fontSize="10"
            fontFamily="JetBrains Mono, monospace"
          >
            Agentic Planner
          </text>

          <path d="M230 38 H250" stroke="#7547CF" strokeWidth="1.5" />

          <rect
            x="250"
            y="20"
            width="94"
            height="36"
            rx="8"
            fill="#14111D"
            stroke="#30283D"
          />
          <text
            x="297"
            y="42"
            textAnchor="middle"
            fill="#F7F5FA"
            fontSize="10"
            fontFamily="JetBrains Mono, monospace"
          >
            Trip Itinerary
          </text>

          <text
            x="18"
            y="88"
            fill="#AAA4B5"
            fontSize="9.5"
            fontFamily="JetBrains Mono, monospace"
          >
            Cox&apos;s Bazar · Saint Martin&apos;s · Sajek · Bandarban
          </text>
        </svg>
      </div>
    </div>
  );
}
