interface SectionHeadingProps {
  kicker: string;
  heading: string;
  lead?: string;
}

export function SectionHeading({ kicker, heading, lead }: SectionHeadingProps) {
  return (
    <div className="max-w-2xl space-y-3">
      <p className="text-xs font-medium tracking-wider text-[#A78BFA]">
        {kicker}
      </p>
      <h2 className="font-display text-2xl font-bold tracking-tight text-[#F7F5FA] sm:text-3xl [text-wrap:balance]">
        {heading}
      </h2>
      {lead && (
        <p className="text-base leading-relaxed text-[#AAA4B5]">{lead}</p>
      )}
    </div>
  );
}
