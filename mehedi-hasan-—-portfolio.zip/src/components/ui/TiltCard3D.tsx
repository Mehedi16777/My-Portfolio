import { useState, type ReactNode } from 'react';
import { calculateCardTilt } from '../../utils/portfolio';

interface TiltCard3DProps {
  children: ReactNode;
  className?: string;
  maxTilt?: number;
}

/**
 * Interactive 3D perspective card wrapper with prismatic rim lighting,
 * depth elevation, and compositor-only transform transitions.
 */
export function TiltCard3D({
  children,
  className = '',
  maxTilt = 6,
}: TiltCard3DProps) {
  const [tilt, setTilt] = useState({
    rotateX: 0,
    rotateY: 0,
    glowX: 50,
    glowY: 50,
    active: false,
  });

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const ny = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    const next = calculateCardTilt(nx, ny, maxTilt);
    setTilt({ ...next, active: true });
  };

  const handlePointerLeave = () => {
    setTilt({ rotateX: 0, rotateY: 0, glowX: 50, glowY: 50, active: false });
  };

  return (
    <div
      style={{ perspective: '960px' }}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      className="h-full"
    >
      <div
        style={{
          transform: tilt.active
            ? `rotateX(${tilt.rotateX}deg) rotateY(${tilt.rotateY}deg) translateZ(10px) scale3d(1.012, 1.012, 1)`
            : 'rotateX(0deg) rotateY(0deg) translateZ(0px) scale3d(1, 1, 1)',
          transformStyle: 'preserve-3d',
          backgroundImage: tilt.active
            ? `radial-gradient(circle at ${tilt.glowX}% ${tilt.glowY}%, rgba(167, 139, 250, 0.22), rgba(117, 71, 207, 0.06) 42%, transparent 68%)`
            : 'linear-gradient(155deg, rgba(167, 139, 250, 0.07) 0%, transparent 45%)',
        }}
        className={`relative h-full transition-transform duration-150 ease-out will-change-transform shadow-[0_24px_52px_-20px_rgba(0,0,0,0.92),0_0_28px_-14px_rgba(117,71,207,0.28),inset_0_1px_0_rgba(216,180,254,0.22)] motion-reduce:transform-none ${className}`}
      >
        {children}
      </div>
    </div>
  );
}
