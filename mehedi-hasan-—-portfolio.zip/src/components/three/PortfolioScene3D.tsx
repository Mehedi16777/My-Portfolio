import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

/**
 * Full-portfolio spatial 3D WebGL corridor using Three.js.
 * Guides the camera across three sculpted 3D landmarks (Hero Astrolabe,
 * Mid-Page Isometric Totem, and Lower Helical Beacon) framed over twin
 * perspective horizon grids, with on-demand damped rendering and software-WebGL protection.
 */
export function PortfolioScene3D() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [webglUnavailable, setWebglUnavailable] = useState(false);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const isSoftwareGl = detectSoftwareWebGL();
    let renderer: THREE.WebGLRenderer;

    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        preserveDrawingBuffer: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglUnavailable(true);
      return;
    }

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = false;
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.setAttribute('aria-hidden', 'true');

    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x09080f, 0.028);

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 90);
    camera.position.set(0, 0.35, 11.5);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // 3-point warm/cool + violet studio lighting rig
    const hemiLight = new THREE.HemisphereLight(0xc4b5fd, 0x09080f, 0.95);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1de, 2.25);
    keyLight.position.set(6, 8, 9);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x8b5cf6, 2.65);
    rimLight.position.set(-7, 2, -4);
    scene.add(rimLight);

    const underFill = new THREE.DirectionalLight(0xa78bfa, 1.35);
    underFill.position.set(4, -9, 3);
    scene.add(underFill);

    const geometries: THREE.BufferGeometry[] = [];
    const materials: THREE.Material[] = [];

    // Shared PBR Material Palette
    const obsidianGlossMat = new THREE.MeshPhysicalMaterial({
      color: 0x18132a,
      roughness: 0.28,
      metalness: 0.45,
      clearcoat: 0.85,
      clearcoatRoughness: 0.18,
    });
    const brushedTitaniumMat = new THREE.MeshStandardMaterial({
      color: 0x6b5c8c,
      roughness: 0.2,
      metalness: 0.9,
    });
    const amethystMat = new THREE.MeshPhysicalMaterial({
      color: 0x8558dc,
      roughness: 0.16,
      metalness: 0.62,
      clearcoat: 0.95,
      clearcoatRoughness: 0.12,
      emissive: 0x3b1b78,
      emissiveIntensity: 0.55,
    });
    const glowingCoreMat = new THREE.MeshStandardMaterial({
      color: 0xc4b5fd,
      roughness: 0.15,
      metalness: 0.4,
      emissive: 0x7547cf,
      emissiveIntensity: 1.05,
    });
    const lavenderWireMat = new THREE.MeshBasicMaterial({
      color: 0xa78bfa,
      wireframe: true,
      transparent: true,
      opacity: 0.38,
    });
    materials.push(
      obsidianGlossMat,
      brushedTitaniumMat,
      amethystMat,
      glowingCoreMat,
      lavenderWireMat,
    );

    // =========================================================================
    // LANDMARK 1: Hero 3D Astrolabe & Crystalline Polyhedron (10 parts)
    // Positioned behind & around Hero portrait stage so orbital rings frame Mehedi
    // =========================================================================
    const heroOrbital = new THREE.Group();
    heroOrbital.position.set(3.55, 0.2, -1.7);
    scene.add(heroOrbital);

    const coreShellGeo = new THREE.IcosahedronGeometry(1.12, 0);
    const coreDiamondGeo = new THREE.OctahedronGeometry(0.66, 0);
    const latticeGeo = new THREE.IcosahedronGeometry(1.48, 1);
    const ring1Geo = new THREE.TorusGeometry(2.58, 0.055, 16, 96);
    const ring2Geo = new THREE.TorusGeometry(3.26, 0.042, 16, 104);
    const ring3Geo = new THREE.TorusGeometry(3.92, 0.026, 12, 112);
    const satGeo = new THREE.OctahedronGeometry(0.19, 0);
    geometries.push(
      coreShellGeo,
      coreDiamondGeo,
      latticeGeo,
      ring1Geo,
      ring2Geo,
      ring3Geo,
      satGeo,
    );

    const coreMesh = new THREE.Mesh(coreShellGeo, obsidianGlossMat);
    const diamondCore = new THREE.Mesh(coreDiamondGeo, glowingCoreMat);
    const latticeMesh = new THREE.Mesh(latticeGeo, lavenderWireMat);
    heroOrbital.add(coreMesh, diamondCore, latticeMesh);

    const ring1Mesh = new THREE.Mesh(ring1Geo, brushedTitaniumMat);
    ring1Mesh.rotation.set(Math.PI * 0.34, 0.16, 0);
    heroOrbital.add(ring1Mesh);

    const ring2Mesh = new THREE.Mesh(ring2Geo, amethystMat);
    ring2Mesh.rotation.set(-Math.PI * 0.24, Math.PI * 0.22, 0.18);
    heroOrbital.add(ring2Mesh);

    const ring3Mesh = new THREE.Mesh(ring3Geo, brushedTitaniumMat);
    ring3Mesh.rotation.set(Math.PI * 0.44, -Math.PI * 0.14, 0.08);
    heroOrbital.add(ring3Mesh);

    const satSpecs: {
      parent: THREE.Mesh;
      pos: [number, number, number];
      mat: THREE.Material;
    }[] = [
      { parent: ring1Mesh, pos: [2.58, 0, 0], mat: glowingCoreMat },
      { parent: ring1Mesh, pos: [-2.58, 0, 0], mat: brushedTitaniumMat },
      { parent: ring2Mesh, pos: [0, 3.26, 0], mat: amethystMat },
      { parent: ring2Mesh, pos: [0, -3.26, 0], mat: glowingCoreMat },
    ];
    satSpecs.forEach(({ parent, pos, mat }) => {
      const sat = new THREE.Mesh(satGeo, mat);
      sat.position.set(...pos);
      parent.add(sat);
    });

    // =========================================================================
    // LANDMARK 2: Mid-Page Isometric Architectural Cluster (About / Skills / Projects)
    // =========================================================================
    const midTotem = new THREE.Group();
    midTotem.position.set(-4.9, -6.1, -3.2);
    scene.add(midTotem);

    const cubeMainGeo = new THREE.BoxGeometry(1.45, 1.45, 1.45);
    const cubeFrameGeo = new THREE.BoxGeometry(2.15, 2.15, 2.15);
    const prismAccentGeo = new THREE.CylinderGeometry(0.18, 0.18, 2.6, 6);
    const collarRingGeo = new THREE.TorusGeometry(2.05, 0.036, 14, 84);
    geometries.push(cubeMainGeo, cubeFrameGeo, prismAccentGeo, collarRingGeo);

    const cubeMain = new THREE.Mesh(cubeMainGeo, obsidianGlossMat);
    cubeMain.rotation.set(0.55, 0.72, 0.2);
    const cubeFrame = new THREE.Mesh(cubeFrameGeo, lavenderWireMat);
    cubeFrame.rotation.set(-0.35, 0.4, 0.15);
    const prismShaft = new THREE.Mesh(prismAccentGeo, amethystMat);
    prismShaft.rotation.z = Math.PI * 0.18;
    const totemCollar = new THREE.Mesh(collarRingGeo, brushedTitaniumMat);
    totemCollar.rotation.set(Math.PI * 0.42, 0.3, 0);
    midTotem.add(cubeMain, cubeFrame, prismShaft, totemCollar);

    // =========================================================================
    // LANDMARK 3: Lower-Page Helical Kinetic Beacon (Journey / Resume / Contact)
    // =========================================================================
    const lowerBeacon = new THREE.Group();
    lowerBeacon.position.set(4.5, -11.4, -3.0);
    scene.add(lowerBeacon);

    const knotGeo = new THREE.TorusKnotGeometry(1.12, 0.24, 96, 18, 2, 3);
    const beaconRingGeo = new THREE.TorusGeometry(2.35, 0.032, 14, 90);
    const beaconCageGeo = new THREE.OctahedronGeometry(2.1, 1);
    geometries.push(knotGeo, beaconRingGeo, beaconCageGeo);

    const knotMesh = new THREE.Mesh(knotGeo, amethystMat);
    const beaconRing = new THREE.Mesh(beaconRingGeo, brushedTitaniumMat);
    beaconRing.rotation.set(Math.PI * 0.35, -0.3, 0);
    const beaconCage = new THREE.Mesh(beaconCageGeo, lavenderWireMat);
    lowerBeacon.add(knotMesh, beaconRing, beaconCage);

    // =========================================================================
    // LANDMARK 1B: Hero Open-Space Isometric Accent Cluster (Desktop Hero depth)
    // =========================================================================
    const heroPrism = new THREE.Group();
    heroPrism.position.set(-0.35, -1.75, -2.3);
    scene.add(heroPrism);

    const heroPrismCoreGeo = new THREE.OctahedronGeometry(0.54, 0);
    const heroPrismCageGeo = new THREE.BoxGeometry(0.96, 0.96, 0.96);
    const heroPrismRingGeo = new THREE.TorusGeometry(0.86, 0.026, 12, 72);
    geometries.push(heroPrismCoreGeo, heroPrismCageGeo, heroPrismRingGeo);

    const heroPrismCore = new THREE.Mesh(heroPrismCoreGeo, amethystMat);
    const heroPrismCage = new THREE.Mesh(heroPrismCageGeo, lavenderWireMat);
    heroPrismCage.rotation.set(0.55, 0.72, 0.25);
    const heroPrismRing = new THREE.Mesh(heroPrismRingGeo, brushedTitaniumMat);
    heroPrismRing.rotation.set(Math.PI * 0.36, -0.35, 0);
    heroPrism.add(heroPrismCore, heroPrismCage, heroPrismRing);

    // =========================================================================
    // Architectural Perspective Horizon Grids (Top Hero Floor + Deep Lower Floor)
    // =========================================================================
    const topGrid = new THREE.GridHelper(54, 40, 0x9f7aea, 0x3b2b59);
    topGrid.position.set(0, -2.9, -4.5);
    scene.add(topGrid);

    const bottomGrid = new THREE.GridHelper(54, 40, 0x8558dc, 0x32244d);
    bottomGrid.position.set(0, -15.2, -5.0);
    scene.add(bottomGrid);

    [topGrid, bottomGrid].forEach((grid, idx) => {
      const gridMats = Array.isArray(grid.material)
        ? grid.material
        : [grid.material];
      gridMats.forEach((m) => {
        m.transparent = true;
        m.opacity = idx === 0 ? 0.48 : 0.42;
        materials.push(m);
      });
      geometries.push(grid.geometry);
    });

    // =========================================================================
    // Deep Instanced Crystalline Prisms (spread cleanly along vertical corridor)
    // =========================================================================
    const nodeCount = 72;
    const nodeGeo = new THREE.OctahedronGeometry(0.072, 0);
    const nodeMat = new THREE.MeshStandardMaterial({
      color: 0xb79df9,
      roughness: 0.28,
      metalness: 0.7,
      emissive: 0x7547cf,
      emissiveIntensity: 0.72,
    });
    geometries.push(nodeGeo);
    materials.push(nodeMat);

    const nodeMesh = new THREE.InstancedMesh(nodeGeo, nodeMat, nodeCount);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < nodeCount; i++) {
      const side = i % 2 === 0 ? 1 : -1;
      const bandX = side * (5.3 + (i % 6) * 0.92);
      const y = 4.2 - (i / nodeCount) * 20.5;
      const depthZ = -4.6 - (i % 6) * 1.45;
      const scale = 0.72 + (i % 4) * 0.22;
      dummy.position.set(bandX, y, depthZ);
      dummy.rotation.set(i * 0.35, i * 0.55, 0);
      dummy.scale.setScalar(scale);
      dummy.updateMatrix();
      nodeMesh.setMatrixAt(i, dummy.matrix);
    }
    nodeMesh.instanceMatrix.needsUpdate = true;
    nodeMesh.computeBoundingSphere();
    scene.add(nodeMesh);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Damped target states for scroll corridor & pointer parallax
    let targetScroll = 0;
    let currentScroll = 0;
    let targetPointerX = 0;
    let targetPointerY = 0;
    let currentPointerX = 0;
    let currentPointerY = 0;

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let disposed = false;
    let lastTime = performance.now();

    const updateTargetsFromScroll = () => {
      const docHeight = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight,
      );
      targetScroll = Math.max(0, Math.min(1, window.scrollY / docHeight));
    };

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync
        ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0)
        : null;
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state =
          sync && gl.getSyncParameter
            ? gl.getSyncParameter(sync, gl.SYNC_STATUS)
            : gl.SIGNALED;
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync && gl.deleteSync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const applyScenePose = () => {
      const aspect = camera.aspect || 1;
      const isNarrow = aspect < 0.85;

      // Vertical corridor camera glide across all 3 landmarks
      const camY = 0.35 - currentScroll * 11.8;
      camera.position.x = currentPointerX * (isNarrow ? 0.25 : 0.48);
      camera.position.y = camY - currentPointerY * 0.28;
      camera.position.z = isNarrow ? 13.8 : 11.4;
      camera.lookAt(0, camY - 0.15, -2.2);

      // Landmark 1: Hero Astrolabe choreography — clearly crowns the top-right perimeter
      // of the portrait stage on desktop, and crowns the portrait card below all links on mobile
      heroOrbital.scale.setScalar(isNarrow ? 0.46 : 0.95);
      heroOrbital.position.set(
        (isNarrow ? 1.65 : 6.35) + currentPointerX * 0.42,
        (isNarrow ? -4.85 : 3.15) - currentPointerY * 0.32,
        isNarrow ? -4.0 : -1.55,
      );
      heroOrbital.rotation.y =
        0.42 + currentScroll * Math.PI * 1.8 + currentPointerX * 0.38;
      heroOrbital.rotation.x =
        0.26 + currentScroll * 0.55 + currentPointerY * 0.25;
      coreMesh.rotation.y = -currentScroll * 2.4;
      diamondCore.rotation.y = currentScroll * 3.1;
      latticeMesh.rotation.z = currentScroll * 1.6;
      ring1Mesh.rotation.z = currentScroll * 2.2;
      ring2Mesh.rotation.z = -currentScroll * 1.8;
      ring3Mesh.rotation.y = -Math.PI * 0.14 + currentScroll * 1.2;

      // Landmark 1B: Open-pocket isometric prism beside Hero intro / CTA gap on desktop
      heroPrism.visible = !isNarrow;
      if (!isNarrow) {
        heroPrism.position.set(
          0.05 + currentPointerX * 0.26,
          -0.55 - currentPointerY * 0.22,
          -2.25,
        );
        heroPrism.rotation.y = 0.5 + currentScroll * 3.2 + currentPointerX * 0.45;
        heroPrism.rotation.x = 0.2 + currentPointerY * 0.32;
        heroPrismCage.rotation.z = -currentScroll * 2.2;
        heroPrismRing.rotation.z = currentScroll * 2.6;
      }

      // Landmark 2: Mid-page architectural totem (sits cleanly below initial Hero fold, frames About/Skills/Projects)
      midTotem.scale.setScalar(isNarrow ? 0.54 : 0.92);
      midTotem.position.set(
        (isNarrow ? -1.8 : 5.75) + currentPointerX * 0.35,
        isNarrow ? -8.4 : -5.85,
        -3.6,
      );
      midTotem.rotation.y = currentScroll * Math.PI * 2.1 + currentPointerX * 0.3;
      midTotem.rotation.x = 0.25 + currentScroll * 0.65;
      cubeFrame.rotation.z = -currentScroll * 1.4;
      totemCollar.rotation.z = currentScroll * 2.0;

      // Landmark 3: Lower helical beacon (flanks lower-right Contact & Resume)
      lowerBeacon.scale.setScalar(isNarrow ? 0.6 : 1);
      lowerBeacon.position.set(
        (isNarrow ? 1.5 : 4.9) + currentPointerX * 0.35,
        -11.5,
        -2.8,
      );
      lowerBeacon.rotation.y =
        -0.4 + currentScroll * Math.PI * 1.9 + currentPointerX * 0.32;
      lowerBeacon.rotation.x = 0.18 + currentPointerY * 0.22;
      knotMesh.rotation.z = currentScroll * 1.7;
      beaconRing.rotation.z = -currentScroll * 2.1;

      nodeMesh.rotation.y = currentScroll * 0.35 + currentPointerX * 0.06;
    };

    const requestRender = () => {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame((now) => {
        if (disposed) return;
        renderDirty = false;
        const delta = Math.min(0.1, Math.max(0.001, (now - lastTime) / 1000));
        lastTime = now;

        if (prefersReducedMotion) {
          currentScroll = targetScroll;
          currentPointerX = 0;
          currentPointerY = 0;
        } else {
          currentScroll = THREE.MathUtils.damp(
            currentScroll,
            targetScroll,
            5.2,
            delta,
          );
          currentPointerX = THREE.MathUtils.damp(
            currentPointerX,
            targetPointerX,
            4.8,
            delta,
          );
          currentPointerY = THREE.MathUtils.damp(
            currentPointerY,
            targetPointerY,
            4.8,
            delta,
          );
        }

        applyScenePose();
        renderer.render(scene, camera);

        const stillSettling =
          !prefersReducedMotion &&
          (Math.abs(currentScroll - targetScroll) > 0.0008 ||
            Math.abs(currentPointerX - targetPointerX) > 0.0008 ||
            Math.abs(currentPointerY - targetPointerY) > 0.0008);

        const done = () => {
          renderBusy = false;
          if (renderDirty || stillSettling) {
            requestRender();
          }
        };

        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    };

    const onScroll = () => {
      updateTargetsFromScroll();
      requestRender();
    };

    const onPointerMove = (e: PointerEvent) => {
      if (prefersReducedMotion) return;
      targetPointerX = (e.clientX / Math.max(1, window.innerWidth) - 0.5) * 2;
      targetPointerY = (e.clientY / Math.max(1, window.innerHeight) - 0.5) * 2;
      requestRender();
    };

    const onResize = () => {
      if (disposed || !container) return;
      const nextW = container.clientWidth || window.innerWidth;
      const nextH = container.clientHeight || window.innerHeight;
      camera.aspect = nextW / nextH;
      camera.updateProjectionMatrix();
      renderer.setSize(nextW, nextH);
      applyScenePose();
      renderer.render(scene, camera);
    };

    const onContextLost = (e: Event) => {
      e.preventDefault();
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
    };

    const onContextRestored = () => {
      applyScenePose();
      renderer.render(scene, camera);
    };

    renderer.domElement.addEventListener('webglcontextlost', onContextLost);
    renderer.domElement.addEventListener(
      'webglcontextrestored',
      onContextRestored,
    );
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    window.addEventListener('resize', onResize);

    updateTargetsFromScroll();
    currentScroll = targetScroll;
    applyScenePose();
    renderer.render(scene, camera);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener(
        'webglcontextrestored',
        onContextRestored,
      );

      geometries.forEach((g) => g.dispose());
      materials.forEach((m) => m.dispose());
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      data-testid="portfolio-3d-canvas"
      aria-hidden="true"
      className={`pointer-events-none fixed inset-0 z-0 ${
        webglUnavailable
          ? 'bg-[radial-gradient(circle_at_78%_22%,rgba(117,71,207,0.22),transparent_52%)]'
          : ''
      }`}
    />
  );
}
