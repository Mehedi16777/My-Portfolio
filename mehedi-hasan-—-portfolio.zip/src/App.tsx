import { useEffect, useState } from 'react';
import { PortfolioScene3D } from './components/three/PortfolioScene3D';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { Hero } from './components/sections/Hero';
import { About } from './components/sections/About';
import { Skills } from './components/sections/Skills';
import { Projects } from './components/sections/Projects';
import { Journey } from './components/sections/Journey';
import { Interests } from './components/sections/Interests';
import { GitHubSection } from './components/sections/GitHubSection';
import { Resume } from './components/sections/Resume';
import { Contact } from './components/sections/Contact';
import { ProjectCaseStudy } from './components/pages/ProjectCaseStudy';
import { NotFoundView } from './components/pages/NotFoundView';
import { projectsData } from './data/projects';
import { translations } from './data/translations';
import type { AppRoute, Language, ProjectSlug } from './types/portfolio';
import {
  findProjectBySlug,
  normalizeLanguage,
  resolveRoute,
} from './utils/portfolio';

const LANGUAGE_STORAGE_KEY = 'mehedi-portfolio-lang';
const SECTION_IDS = [
  'home',
  'about',
  'skills',
  'projects',
  'journey',
  'interests',
  'github',
  'resume',
  'contact',
];

export default function App() {
  const [language, setLanguage] = useState<Language>(() => {
    try {
      return normalizeLanguage(window.localStorage.getItem(LANGUAGE_STORAGE_KEY));
    } catch {
      return 'en';
    }
  });

  const [route, setRoute] = useState<AppRoute>(() =>
    resolveRoute(window.location.pathname),
  );
  const [activeSection, setActiveSection] = useState<string>('home');

  const t = translations[language];

  useEffect(() => {
    document.documentElement.lang = language;
    try {
      window.localStorage.setItem(LANGUAGE_STORAGE_KEY, language);
    } catch {
      // Ignore storage errors in restricted contexts
    }
  }, [language]);

  useEffect(() => {
    const handlePopState = () => {
      setRoute(resolveRoute(window.location.pathname));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    if (route.view === 'project') {
      const project = findProjectBySlug(projectsData, route.slug);
      document.title = project
        ? `${project.title} — Mehedi Hasan`
        : 'Mehedi Hasan — Portfolio';
    } else if (route.view === 'not-found') {
      document.title = '404 — Mehedi Hasan';
    } else {
      document.title =
        'Mehedi Hasan — Software Engineering Student & Aspiring Developer';
    }
  }, [route]);

  useEffect(() => {
    if (route.view !== 'home') {
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);

        if (visible.length > 0 && visible[0].target.id) {
          setActiveSection(visible[0].target.id);
        }
      },
      {
        rootMargin: '-25% 0px -55% 0px',
        threshold: [0.1, 0.25, 0.5],
      },
    );

    SECTION_IDS.forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        observer.observe(el);
      }
    });

    return () => observer.disconnect();
  }, [route.view]);

  const scrollToSection = (sectionId: string) => {
    const target = document.getElementById(sectionId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setActiveSection(sectionId);
    }
  };

  const handleNavigateHome = (sectionId?: string) => {
    if (route.view !== 'home') {
      window.history.pushState({}, '', sectionId ? `/#${sectionId}` : '/');
      setRoute({ view: 'home' });
      window.requestAnimationFrame(() => {
        if (sectionId) {
          scrollToSection(sectionId);
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      });
      return;
    }

    if (sectionId) {
      window.history.replaceState({}, '', `/#${sectionId}`);
      scrollToSection(sectionId);
    } else {
      window.history.replaceState({}, '', '/');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setActiveSection('home');
    }
  };

  const handleOpenProject = (slug: ProjectSlug) => {
    const path = `/projects/${slug}`;
    window.history.pushState({}, '', path);
    setRoute({ view: 'project', slug });
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  const activeProject =
    route.view === 'project'
      ? findProjectBySlug(projectsData, route.slug)
      : undefined;

  return (
    <div className="relative flex min-h-screen flex-col bg-[#09080F] text-[#F7F5FA]">
      <PortfolioScene3D />

      <div className="relative z-10 flex min-h-screen flex-col">
        <Header
          language={language}
          onLanguageChange={setLanguage}
          t={t}
          activeSection={activeSection}
          isHomeView={route.view === 'home'}
          onNavigateHome={handleNavigateHome}
        />

        <main id="main-content" className="flex-1">
          {route.view === 'home' && (
            <>
              <Hero
                language={language}
                t={t}
                onScrollToSection={scrollToSection}
              />
              <About t={t} />
              <Skills language={language} t={t} />
              <Projects
                language={language}
                t={t}
                onOpenProject={handleOpenProject}
              />
              <Journey language={language} t={t} />
              <Interests t={t} />
              <GitHubSection language={language} t={t} />
              <Resume language={language} t={t} />
              <Contact t={t} />
            </>
          )}

          {route.view === 'project' && activeProject && (
            <ProjectCaseStudy
              project={activeProject}
              language={language}
              t={t}
              onBackHome={() => handleNavigateHome('projects')}
            />
          )}

          {route.view === 'not-found' && (
            <NotFoundView t={t} onBackHome={() => handleNavigateHome()} />
          )}
        </main>

        <Footer t={t} onNavigateHome={handleNavigateHome} />
      </div>
    </div>
  );
}
