# Mehedi Hasan --- Personal Portfolio Website

## Master Development Prompt for Claude Free

> **Purpose:** Build a premium, modern, bilingual personal portfolio
> website for Mehedi Hasan. **Important:** Use this document as the
> project source of truth. Build the website phase by phase. Do not
> attempt to generate the entire application in one response.

------------------------------------------------------------------------

# 1. Your Role

Act as a senior UI/UX designer, frontend architect, and experienced
Next.js developer.

Your job is to design and build a polished, production-quality personal
portfolio website for **Mehedi Hasan**. The website should establish a
strong personal brand and present him as a software engineering student,
aspiring software developer, and AI enthusiast.

The result must feel carefully art-directed, professional, fast,
accessible, and memorable---not like a generic portfolio template.

# 2. Owner Profile and Verified Information

Use the following information as the source of truth:

-   **Name:** Mehedi Hasan
-   **Preferred professional title:** Student & Aspiring Developer
-   **Suggested public-facing headline:** Software Engineering Student
    \| Aspiring Software Developer \| AI Enthusiast
-   **Portfolio purpose:** Personal branding
-   **GitHub:** https://github.com/Mehedi16777
-   **LinkedIn:** Not provided yet. Do not invent a URL.
-   **Skills supplied:** Python, HTML, JavaScript, AI, React, Next.js,
    Node.js
-   **Projects supplied:**
    1.  Bus Ticket Reservation System
    2.  Sagar--Pahar AI Travel Agent
-   **Special requirement:** Download CV
-   **Languages:** English and Bangla

Some details are not yet available, including profile photo, email,
university, department, academic year, LinkedIn URL, CV PDF, project
repository URLs, live demo URLs, and project screenshots.

**Never fabricate personal information, qualifications, project
outcomes, employment history, awards, certifications, statistics, email
addresses, or URLs.** For missing details, use clearly marked editable
placeholders in a central content file and hide optional UI elements
until real content is supplied. Do not display fake percentages, fake
GitHub statistics, or made-up testimonials.

# 3. Product Vision

Create a premium personal portfolio that communicates:

-   Who Mehedi Hasan is.
-   His interest in software engineering and artificial intelligence.
-   His technical skills and learning journey.
-   The real projects he has built.
-   His approach to solving problems.
-   How visitors can connect with him or explore his work.

The portfolio should support personal branding, networking, and future
career opportunities.

# 4. Visual Design Direction

## Core aesthetic

Use an **Apple-inspired clean design combined with a creative developer
portfolio feel**.

The visual language should be: - Minimal, elegant, premium, and
editorial. - Spacious, with strong visual hierarchy. - Dark, refined,
and technology-oriented. - Distinctive without being visually noisy. -
Consistent across every page and component.

Do not copy Apple's website or any existing portfolio. Use the general
principles of clarity, restraint, typography, whitespace, and polished
interaction.

## Color palette

Use black and deep purple as the primary identity.

Suggested design tokens:

  Token              Suggested value   Usage
  ------------------ ----------------- ------------------------------
  Background         `#09080F`         Main page background
  Surface            `#14111D`         Cards and panels
  Elevated surface   `#1C1728`         Hover and elevated areas
  Primary purple     `#7547CF`         Primary actions and accents
  Soft lavender      `#A78BFA`         Highlights and focus
  Main text          `#F7F5FA`         Headings and body text
  Muted text         `#AAA4B5`         Secondary information
  Border             `#30283D`         Subtle dividers and outlines

Keep contrast accessible. Purple should be an accent, not a color
applied to every element. Avoid excessive gradients, neon glow, and
large areas of saturated purple.

## Typography

Use a modern, readable sans-serif font. Choose a suitable web font such
as Inter, Geist, or another available high-quality alternative. Use: -
Large, confident hero typography. - Clear section headings. -
Comfortable body text line-height. - Consistent font weights and
spacing.

## Motion and interaction

Use balanced animation: - Subtle entrance and scroll-reveal effects. -
Smooth anchor scrolling. - Small hover transitions on buttons and
project cards. - Gentle background details if they improve the design. -
Respect `prefers-reduced-motion`. - Avoid distracting continuous
animations, excessive parallax, and performance-heavy effects.

# 5. Technology Stack

Prefer the following stack:

-   Next.js using the App Router.
-   React.
-   TypeScript.
-   Tailwind CSS.
-   Framer Motion or Motion for React, if compatible with the selected
    project setup.
-   Lucide React for icons.
-   Git and GitHub for version control.
-   Vercel for deployment.

Use stable, mutually compatible package versions. Before installing or
changing dependencies, inspect the existing project and package files.
Do not replace working configuration without a reason.

The initial portfolio should not require a database or custom backend.
Use static content and client-side interactions where appropriate. Add a
backend or third-party service only when a real requirement needs it.

# 6. Website Information Architecture

Build the portfolio as a polished single-page website with reusable
components and optional project case-study routes.

## A. Header and Navigation

Include: - MEHEDI. wordmark. - Home - About - Skills - Projects -
Journey - GitHub - Resume - Contact - English/Bangla language switch. -
Mobile navigation menu.

Requirements: - Sticky or intelligently positioned header. - Active
section indication. - Smooth navigation. - Accessible keyboard
operation. - Mobile menu must open and close correctly. - Avoid
overcrowding on desktop.

## B. Hero Section

The hero must immediately communicate the owner's identity and value.

Suggested English copy:

**Eyebrow:** SOFTWARE ENGINEERING · AI · TECHNOLOGY

**Headline:** Building ideas into meaningful digital experiences.

**Introduction:** I'm Mehedi Hasan, a software engineering student and
aspiring developer passionate about software development, artificial
intelligence, and building useful digital products.

Primary CTA: Explore Projects\
Secondary CTA: Download CV

Also include: - GitHub link. - LinkedIn link only when supplied. - A
tasteful visual element, abstract graphic, or restrained code-inspired
detail. - A subtle location label such as "Based in Bangladesh" only if
the owner confirms it. - Do not invent "available for work" or "open to
opportunities" status.

The hero should look premium and distinctive, not like a generic
centered template.

## C. About Me

Include: - Short introduction. - Software engineering journey. -
Interest in AI and technology. - What kinds of problems he enjoys
solving. - Current learning focus. - Future goals.

Use editable content placeholders for information that has not been
provided. Do not invent a biography.

## D. Skills and Technologies

Organize the supplied skills into groups:

**Programming:** Python, JavaScript\
**Frontend:** HTML, React, Next.js\
**Backend:** Node.js\
**AI & Machine Learning:** Artificial Intelligence, Machine Learning

Use clean skill cards, labels, or icon groups. Do not show invented
proficiency percentages or skill ratings. Make the distinction between a
technology the owner has used and one he is currently learning editable
in the content data.

## E. Featured Projects

Show the two supplied projects prominently.

### Project 1: Bus Ticket Reservation System

Create a project card and a detailed case-study template with: - Project
overview. - Problem being addressed. - Main features. - Technologies
used. - Screenshots or product images. - What the owner contributed. -
Challenges and learning. - GitHub repository link. - Live demo link, if
available.

Do not invent the system's features, tech stack, or project results.
Keep unknown fields as editable placeholders and hide empty links.

### Project 2: Sagar--Pahar AI Travel Agent

Project title: **Sagar--Pahar AI Travel Agent**

Suggested subtitle: **An Agentic AI-Powered Trip Planning, Ride Rental
and Booking Platform**

Use only the following project context as supplied: - Bangladesh-focused
travel platform. - AI-powered personalized trip planning and itinerary
generation. - Budget optimization. - Hotel/accommodation and transport
information. - Ride and local experience marketplace. - Local tourism
experiences such as cycling where permitted and other
destination-specific activities. - The concept includes destinations
such as Cox's Bazar, Saint Martin's Island, Sajek Valley, and Bandarban.

Present this as a project concept/prototype unless the owner confirms it
is fully implemented. Clearly distinguish implemented features from
planned features. Do not claim real booking integrations, live
availability, or production deployment unless verified.

Create a detailed case-study page/template with: - Project overview. -
Problem and target users. - Proposed solution. - Agentic AI workflow. -
Main features. - Technology stack (editable; do not assume unconfirmed
technologies). - Architecture or workflow visual. - Screenshots. -
Current development status. - GitHub and live demo links, if supplied.

### Project card behavior

Each project card should include: - Project name. - Short accurate
description. - Technology tags only when confirmed. - "View Case Study"
action. - GitHub and Live Demo actions only when valid links exist.

Use a consistent, reusable project data structure.

## F. Education and Journey

Provide an editable timeline or structured section for: -
University/institution. - Department. - Degree/program. - Academic
period. - Relevant coursework. - Certifications, if any. - Learning
milestones.

Do not display placeholder credentials as real facts. Hide empty
entries.

## G. Interests / What I Do

Show selected interests: - Software Development. - Artificial
Intelligence. - Machine Learning. - Problem Solving. - Exploring New
Technologies.

Keep the presentation concise and visually consistent.

## H. GitHub Section

Include a link to: https://github.com/Mehedi16777

Possible features: - GitHub profile card. - Public repository list. -
Repository descriptions. - Programming-language information when
available. - Contribution activity only if it can be fetched reliably
from a legitimate source.

Do not hardcode fake contribution data or statistics. If a live GitHub
API integration is added, handle rate limits, loading states, missing
data, and API failures gracefully. The website must still work if GitHub
data is unavailable.

## I. Resume / CV

Include: - Download CV button. - Optional PDF preview. - A clearly
documented location for the owner to add the real CV file. - Graceful
fallback if the CV has not yet been supplied.

Do not create a fake CV. Do not show a download button that points to a
missing file.

## J. Contact

Include: - Email address only after it is supplied. - GitHub. - LinkedIn
only after a valid URL is supplied. - Contact form with name, email,
subject, and message. - Client-side validation. - Accessible error and
success states.

Important: A frontend-only form must not pretend to send messages. If no
form backend/service is configured, either show a clearly explained
email-based contact option when an email is supplied or leave the form
disabled with setup instructions. Never expose secret API keys in
frontend code.

## K. Footer

Include: - Mehedi Hasan wordmark. - Short brand statement. - Navigation
links. - Valid social links. - Copyright year generated dynamically. -
Back-to-top action.

# 7. English and Bangla Language Support

The website must support both English and Bangla.

Requirements: - A visible EN / বাংলা toggle. - English as the default
language. - All navigation labels, headings, descriptions, buttons, form
messages, and relevant UI copy must switch languages. - Do not translate
names, technology names, URLs, or project titles unnecessarily. - Use
natural, readable Bangla---not awkward word-for-word translations. -
Persist the selected language during the current browsing session or
using a suitable lightweight preference mechanism. - Ensure the chosen
font supports Bangla glyphs correctly. - Check Bangla line wrapping and
spacing on desktop and mobile.

Store translations centrally. Do not scatter conditional language
strings across many components.

# 8. Pages and Routes

At minimum: - `/` --- Main portfolio. -
`/projects/bus-ticket-reservation` --- Project case study. -
`/projects/sagar-pahar-ai-travel-agent` --- Project case study. - Custom
not-found page.

If building detailed project routes would delay the initial release,
complete the main portfolio first and add case-study pages in a later
phase.

# 9. Responsive Design

Although the design process should prioritize desktop, the finished
website must be fully responsive.

Test at: - Large desktop. - Standard laptop. - Tablet. - Mobile.

Requirements: - No horizontal overflow. - Responsive typography. -
Navigation adapts to smaller screens. - Project cards stack cleanly. -
Touch targets are comfortable. - Images use appropriate responsive
sizing. - Animations remain smooth on lower-powered devices.

# 10. Accessibility, SEO, and Performance

## Accessibility

-   Semantic HTML.
-   Keyboard-accessible navigation and controls.
-   Visible focus states.
-   Appropriate color contrast.
-   Descriptive alt text.
-   Labels for form fields.
-   Reduced-motion support.
-   Correct heading hierarchy.

## SEO

-   Unique page title and meta description.
-   Open Graph metadata.
-   Favicon.
-   Canonical URL when the deployment domain is known.
-   Descriptive project page metadata.
-   Sitemap and robots configuration where appropriate.

Do not invent a custom domain or public contact details.

## Performance

-   Optimize images.
-   Avoid unnecessary dependencies.
-   Use Next.js image optimization where suitable.
-   Avoid layout shifts.
-   Lazy-load non-critical media.
-   Keep animations lightweight.
-   Avoid unnecessary client components.
-   Aim for strong Core Web Vitals and Lighthouse results without
    sacrificing usability.

# 11. Code Quality and Architecture

Use: - Reusable components. - Clear folder organization. - TypeScript
types for content data. - Centralized site configuration. - Centralized
English/Bangla translations. - Centralized project data. - Consistent
naming conventions. - Clean and maintainable code. - Small components
with clear responsibilities.

Suggested structure (adapt to the actual Next.js version and project
setup):

``` text
app/
  layout.tsx
  page.tsx
  globals.css
  not-found.tsx
  projects/
    bus-ticket-reservation/
      page.tsx
    sagar-pahar-ai-travel-agent/
      page.tsx

components/
  layout/
    Header.tsx
    Footer.tsx
    MobileMenu.tsx
  sections/
    Hero.tsx
    About.tsx
    Skills.tsx
    Projects.tsx
    Journey.tsx
    Interests.tsx
    GitHub.tsx
    Resume.tsx
    Contact.tsx
  ui/
    Button.tsx
    SectionHeading.tsx
    ProjectCard.tsx
    SocialLinks.tsx

data/
  site.ts
  projects.ts
  translations.ts
  skills.ts
  journey.ts

public/
  images/
  documents/
```

Do not force this exact structure if the framework version or existing
codebase calls for a better arrangement.

# 12. Claude Free Workflow --- Mandatory Rules

Because this project is being built using Claude Free, work
incrementally.

**Never generate the entire website in one response.**

Follow these rules:

1.  Work on one phase at a time.
2.  Inspect the existing files before editing them.
3.  Before changing a file, understand its current role and
    dependencies.
4.  Return complete code for every file you create or modify, unless the
    user explicitly asks for a smaller patch.
5.  Always state the exact file path for each code block.
6.  Do not omit required imports or silently replace code with comments
    such as "rest of code here".
7.  Do not invent package names, APIs, or configuration options.
8.  Keep a record of completed phases and remaining tasks.
9.  After each phase, explain how to run and test the changes.
10. Fix errors before moving to the next phase.
11. Avoid changing unrelated files.
12. If the response is becoming too long, stop at a safe point and
    explain exactly what remains.
13. If the user starts a new Claude conversation, use the project
    handoff summary described below.

## Required phase order

### Phase 1 --- Inspect and Set Up

-   Ask whether the user already has a project folder.
-   If a project exists, inspect its structure and configuration first.
-   If not, provide exact setup commands.
-   Set up Next.js, TypeScript, and Tailwind CSS using compatible
    current instructions.
-   Verify the development server runs.

### Phase 2 --- Design System and Layout

-   Implement design tokens.
-   Set up typography.
-   Build header, footer, navigation, and shared UI components.
-   Establish desktop and mobile layout behavior.

### Phase 3 --- Main Portfolio Sections

-   Build Hero.
-   Build About.
-   Build Skills.
-   Build Projects.
-   Build Education/Journey.
-   Build Interests.
-   Build Resume.
-   Build Contact.

### Phase 4 --- Bilingual Support and Interactions

-   Add English/Bangla language switching.
-   Add smooth scrolling.
-   Add balanced animations.
-   Add project interactions.
-   Add CV download behavior when the real file is available.

### Phase 5 --- Project Case Studies and GitHub

-   Build the two case-study pages.
-   Add real repository links when provided.
-   Add GitHub data integration only if it can be implemented reliably.

### Phase 6 --- SEO, Accessibility, and Testing

-   Add metadata.
-   Test keyboard navigation and contrast.
-   Test all links and forms.
-   Test desktop, tablet, and mobile.
-   Fix runtime and build errors.
-   Check performance.

### Phase 7 --- Deployment

-   Prepare GitHub repository.
-   Explain environment variables, if any.
-   Deploy to Vercel.
-   Verify the deployed website.
-   Explain how to update content and redeploy.

# 13. Project Handoff Summary

At the end of every phase, output a compact handoff summary in this
format:

``` text
PROJECT: Mehedi Hasan Portfolio

COMPLETED:
- [List completed tasks]

CURRENT PROJECT STRUCTURE:
- [Relevant folders and files]

DESIGN DECISIONS:
- [Colors, typography, layout, animation decisions]

DEPENDENCIES:
- [Installed packages and versions, if known]

TEST STATUS:
- [Commands run and results]

REMAINING:
- [Tasks not yet completed]

NEXT PHASE:
- [Exact next task]

IMPORTANT NOTES:
- [Known issues, missing personal information, or setup requirements]
```

The handoff summary must be accurate and must not claim that untested
features work.

# 14. Final Quality Checklist

Before declaring the project complete, verify:

-   [ ] The website communicates Mehedi Hasan's identity clearly.
-   [ ] Black and deep purple visual identity is consistent.
-   [ ] Design feels premium, clean, and original.
-   [ ] Hero section has a strong introduction and clear calls to
    action.
-   [ ] All supplied skills are represented accurately.
-   [ ] Both supplied projects are featured.
-   [ ] Planned project features are distinguished from implemented
    features.
-   [ ] English/Bangla switching works across the entire interface.
-   [ ] CV download works only when a real CV file exists.
-   [ ] GitHub link works.
-   [ ] LinkedIn is hidden until a valid URL is provided.
-   [ ] Contact form does not falsely claim to send messages.
-   [ ] No fake statistics, testimonials, achievements, or personal
    details.
-   [ ] Desktop layout is polished.
-   [ ] Mobile and tablet layouts work.
-   [ ] No broken links or missing images.
-   [ ] No console errors or build errors.
-   [ ] SEO metadata is present.
-   [ ] Accessibility basics are covered.
-   [ ] Deployment instructions are documented.

# 15. First Message to Claude --- Start Here

Start by acknowledging the project brief.

**Do not build the entire website immediately.**

First: 1. Ask whether I am starting from an empty folder or already have
a Next.js project. 2. Ask me to share the current project file structure
if one exists. 3. Confirm the recommended stack and explain any
compatibility concerns. 4. Begin **Phase 1 only**. 5. Give me
beginner-friendly terminal commands, one step at a time. 6. Wait for my
result when a command needs to be run before continuing.

Keep explanations clear and practical. Assume I may need help running
commands, locating files, and understanding errors.

The final website should look like a carefully designed personal brand
experience---not a copied template.
